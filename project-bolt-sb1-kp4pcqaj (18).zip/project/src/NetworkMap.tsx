import React, { useRef, useEffect, useMemo, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';
import { 
  AlertTriangle, 
  Monitor, 
  Server, 
  Laptop, 
  Smartphone, 
  Router as RouterIcon,
  Database,
  Printer,
  Network,
  HardDrive,
  Wifi,
  Globe,
  Activity
} from 'lucide-react';

// ... (keep all the interfaces and type definitions)

function Node({ device, position }: { device: Device; position: [number, number, number] }) {
  const [hovered, setHovered] = React.useState(false);
  const DeviceIcon = getDeviceIcon(device);

  const getNodeColor = (status: string) => {
    switch (status) {
      case 'compromised': return '#ff0033';
      case 'warning': return '#f59e0b';
      default: return '#00f7ff';
    }
  };

  const color = getNodeColor(device.status);

  return (
    <group position={position}>
      <Html center>
        <div 
          className="device-icon"
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
        >
          <DeviceIcon 
            className="h-6 w-6"
            style={{ 
              color,
              filter: `drop-shadow(0 0 4px ${color})`,
              opacity: hovered ? 1 : 0.8,
            }}
          />
        </div>
      </Html>

      {device.ports.map((port, index) => (
        <PortRing
          key={port.port}
          port={port.port}
          index={index}
          total={device.ports.length}
          radius={0.6}
        />
      ))}

      {device.hypervisor && (
        <Html position={[0, 0.5, 0]} center>
          <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded flex items-center gap-1">
            <Monitor className="h-3 w-3" />
            <span>{device.hypervisor.type === 'hypervisor' ? 'Hypervisor' : 'VM'}</span>
          </div>
        </Html>
      )}

      <Html position={[0, -0.8, 0]} center>
        <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded">
          {device.ip}
        </div>
      </Html>

      {hovered && (
        <Html position={[0, 0.8, 0]}>
          <div className="bg-[#111111] border border-[#00f7ff] p-2 rounded text-xs text-[#00f7ff] whitespace-nowrap">
            <div>{device.hostname}</div>
            <div>OS: {device.os.name}</div>
            <div>Ports: {device.ports.map(p => p.port).join(', ')}</div>
            {device.hypervisor && (
              <div>
                {device.hypervisor.type === 'vm' ? (
                  <>VM ({device.hypervisor.hypervisor})</>
                ) : (
                  <>Hypervisor ({device.hypervisor.name})</>
                )}
              </div>
            )}
            <div className={`capitalize ${device.status === 'compromised' ? 'text-[#ff0033]' : ''}`}>
              Status: {device.status}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function DataStream({ start, end }) {
  const ref = useRef();

  useFrame((state) => {
    if (ref.current) {
      ref.current.material.dashOffset -= 0.01;
    }
  });

  const points = [
    new THREE.Vector3(...start),
    new THREE.Vector3(...end),
  ];
  
  const curve = new THREE.CatmullRomCurve3(points);

  return (
    <mesh>
      <tubeGeometry args={[curve, 64, 0.02, 8, false]} />
      <meshBasicMaterial
        ref={ref}
        color="#00ff00"
        transparent
        opacity={0.4}
        dashSize={0.1}
        gapSize={0.1}
      />
    </mesh>
  );
}

function Scene({ networkData }) {
  const { camera } = useThree();
  const [showRouterInfo, setShowRouterInfo] = useState(false);
  
  useEffect(() => {
    camera.position.set(0, 0, 10);
    camera.lookAt(0, 0, 0);
  }, [camera]);

  if (!networkData?.devices) {
    return null;
  }

  return (
    <group>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1.5} />
      
      {/* Router */}
      <group
        onPointerOver={() => setShowRouterInfo(true)}
        onPointerOut={() => setShowRouterInfo(false)}
      >
        <Html center>
          <div className="device-icon transform scale-125">
            <RouterIcon 
              className="h-8 w-8"
              style={{ 
                color: '#00ff00',
                filter: 'drop-shadow(0 0 6px #00ff00)',
              }}
            />
          </div>
          {showRouterInfo && (
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 z-50 whitespace-nowrap">
              <RouterInfo />
            </div>
          )}
        </Html>
      </group>

      {/* Data Streams */}
      {networkData.devices.map((device, i) => {
        const position = calculateNodePosition(i, networkData.devices.length, 4);
        return (
          <React.Fragment key={device.ip}>
            <DataStream start={[0, 0, 0]} end={position} />
            <Node device={device} position={position} />
          </React.Fragment>
        );
      })}

      <OrbitControls
        enableZoom={true}
        minDistance={5}
        maxDistance={20}
        enablePan={false}
      />
    </group>
  );
}

// ... (keep all the helper functions like calculateNodePosition, getDeviceIcon, etc.)

export function NetworkMap({ networkData }: { networkData: NetworkData | null }) {
  const hasCompromisedDevices = networkData?.devices.some(d => d.status === 'compromised');

  return (
    <div className="cyber-panel h-[600px] relative grid-bg">
      <Canvas>
        <Scene networkData={networkData} />
      </Canvas>
      
      {hasCompromisedDevices && (
        <div className="absolute top-4 right-4 flex items-center space-x-2 text-[#ff0033]">
          <AlertTriangle className="h-5 w-5" />
          <span>THREAT DETECTED</span>
        </div>
      )}
      
      <div className="absolute bottom-4 left-4 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-2">
            <RouterIcon className="h-4 w-4 text-[#00ff00]" />
            <span>Router</span>
          </div>
          <div className="flex items-center space-x-2">
            <Server className="h-4 w-4 text-[#00f7ff]" />
            <span>Server</span>
          </div>
          <div className="flex items-center space-x-2">
            <Monitor className="h-4 w-4 text-[#00f7ff]" />
            <span>Desktop/VM</span>
          </div>
          <div className="flex items-center space-x-2">
            <Laptop className="h-4 w-4 text-[#00f7ff]" />
            <span>Laptop</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-[#00f7ff]" />
            <span>Storage</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#ff0033]"></div>
            <span>Compromised</span>
          </div>
        </div>
      </div>
    </div>
  );
}