#!/usr/bin/env python3

import sys
import logging
import subprocess
import os
import socket
import time
import requests
import platform
import json
from pathlib import Path
from typing import List, Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

class HealthChecker:
    def __init__(self):
        self.overall_status = True
        self.issues = []
        self.warnings = []
        self.successes = []
        
        # Load dynamic configuration from .env file
        self.backend_port, self.frontend_port, self.backend_url, self.frontend_url = self._load_env_vars()

    def _load_env_vars(self) -> tuple:
        """Load environment variables from .env file and return port configuration."""
        # Default values
        backend_port = 5000
        frontend_port = 5173
        backend_url = f"http://localhost:{backend_port}"
        frontend_url = f"http://localhost:{frontend_port}"
        
        env_file = Path('.env')
        if env_file.exists():
            try:
                with open(env_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith('VITE_BACKEND_API_URL='):
                            backend_url = line.split('=', 1)[1]
                            # Extract port from URL
                            try:
                                backend_port = int(backend_url.split(':')[-1])
                            except (ValueError, IndexError):
                                pass
                        elif line.startswith('VITE_PORT='):
                            try:
                                frontend_port = int(line.split('=', 1)[1])
                                frontend_url = f"http://localhost:{frontend_port}"
                            except ValueError:
                                pass
                
                logging.info(f"📋 Loaded configuration from .env:")
                logging.info(f"   Backend: {backend_url} (port {backend_port})")
                logging.info(f"   Frontend: {frontend_url} (port {frontend_port})")
                
            except Exception as e:
                logging.warning(f"⚠️  Error reading .env file: {e}")
                logging.info("📋 Using default port configuration")
        else:
            logging.info("📋 No .env file found, using default port configuration")
        
        return backend_port, frontend_port, backend_url, frontend_url

    def log_success(self, message: str):
        """Log a successful check."""
        logging.info(f"✅ {message}")
        self.successes.append(message)

    def log_warning(self, message: str):
        """Log a warning."""
        logging.warning(f"⚠️  {message}")
        self.warnings.append(message)

    def log_error(self, message: str):
        """Log an error and mark overall status as failed."""
        logging.error(f"❌ {message}")
        self.issues.append(message)
        self.overall_status = False

    def run_command(self, command: List[str], cwd: Optional[str] = None, capture_output: bool = False, timeout: int = 30) -> Optional[str]:
        """Helper to run shell commands."""
        try:
            logging.debug(f"Running command: {' '.join(command)}")
            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=capture_output,
                text=True,
                check=True,
                timeout=timeout
            )
            if capture_output:
                return result.stdout.strip()
            return "success"
        except subprocess.CalledProcessError as e:
            logging.debug(f"Command failed: {' '.join(command)}")
            if capture_output and e.stdout:
                logging.debug(f"STDOUT: {e.stdout}")
            if capture_output and e.stderr:
                logging.debug(f"STDERR: {e.stderr}")
            return None
        except FileNotFoundError:
            logging.debug(f"Command not found: {command[0]}")
            return None
        except subprocess.TimeoutExpired:
            logging.debug(f"Command timed out: {' '.join(command)}")
            return None
        except Exception as e:
            logging.debug(f"Unexpected error running command {' '.join(command)}: {e}")
            return None

    def check_port_available(self, port: int) -> bool:
        """Check if a port is available for use."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('localhost', port))
                return True
        except socket.error:
            return False

    def check_port_in_use(self, port: int) -> bool:
        """Check if a port is currently in use."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                result = s.connect_ex(('localhost', port))
                return result == 0
        except Exception:
            return False

    def wait_for_server(self, url: str, timeout: int = 30, name: str = "Server") -> bool:
        """Wait for a server to become responsive."""
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = requests.get(url, timeout=5)
                if response.status_code == 200:
                    self.log_success(f"{name} is responsive at {url}")
                    return True
            except requests.exceptions.RequestException:
                pass
            time.sleep(1)
        
        self.log_error(f"{name} failed to become responsive within {timeout} seconds at {url}")
        return False

    def check_api_endpoint(self, url: str, method: str = 'GET', data: Optional[Dict] = None, name: str = "API Endpoint") -> bool:
        """Check if a specific API endpoint is responsive."""
        try:
            if method == 'GET':
                response = requests.get(url, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, timeout=10)
            else:
                self.log_error(f"Unsupported method for API endpoint check: {method}")
                return False

            if response.status_code == 200:
                self.log_success(f"{name} ({url}) is responsive (Status: {response.status_code})")
                return True
            else:
                self.log_error(f"{name} ({url}) returned unexpected status code: {response.status_code}")
                return False
        except requests.exceptions.RequestException as e:
            self.log_error(f"Failed to connect to {name} ({url}): {e}")
            return False
        except Exception as e:
            self.log_error(f"Unexpected error checking {name} ({url}): {e}")
            return False

    def check_dependency(self, name: str, command: List[str], min_version: Optional[str] = None, install_instructions: Optional[str] = None) -> bool:
        """Check if a dependency is installed and meets minimum version."""
        logging.info(f"🔍 Checking {name}...")
        
        version_output = self.run_command(command, capture_output=True, timeout=10)
        if not version_output:
            self.log_error(f"{name} not found or command failed")
            if install_instructions:
                logging.info(f"   Installation instructions: {install_instructions}")
            return False

        self.log_success(f"{name} found: {version_output}")
        
        if min_version:
            try:
                # Extract version number from output
                version_parts = version_output.split()
                current_version = None
                
                for part in version_parts:
                    if part.replace('v', '').replace('.', '').isdigit() or '.' in part:
                        current_version = part.replace('v', '')
                        break
                
                if not current_version:
                    self.log_warning(f"Could not parse version from: {version_output}")
                    return True
                
                # Simple version comparison
                current_parts = [int(x) for x in current_version.split('.') if x.isdigit()]
                min_parts = [int(x) for x in min_version.split('.')]
                
                # Pad shorter version with zeros
                while len(current_parts) < len(min_parts):
                    current_parts.append(0)
                while len(min_parts) < len(current_parts):
                    min_parts.append(0)

                if current_parts >= min_parts:
                    self.log_success(f"{name} version {current_version} meets minimum requirement {min_version}")
                    return True
                else:
                    self.log_error(f"{name} version {current_version} is below minimum requirement {min_version}")
                    if install_instructions:
                        logging.info(f"   Update instructions: {install_instructions}")
                    return False
            except Exception as e:
                self.log_warning(f"Error comparing versions for {name}: {e}")
                return True
        
        return True

    def check_python_dependencies(self) -> bool:
        """Check if Python dependencies are installed."""
        logging.info("🔍 Checking Python dependencies...")
        
        requirements_file = Path("server/requirements.txt")
        if not requirements_file.exists():
            self.log_error(f"Python requirements file not found: {requirements_file}")
            return False
        
        try:
            # Check if pip is working
            pip_check = self.run_command([sys.executable, '-m', 'pip', '--version'], capture_output=True, timeout=10)
            if not pip_check:
                self.log_error("pip is not available or not working")
                return False
            
            # Try to install/verify dependencies
            logging.info("Verifying Python dependencies...")
            install_result = self.run_command([
                sys.executable, '-m', 'pip', 'install', '-r', str(requirements_file)
            ], timeout=120)
            
            if install_result:
                self.log_success("Python dependencies are installed and verified")
                return True
            else:
                self.log_error("Failed to install/verify Python dependencies")
                logging.info("   Try running: pip install -r server/requirements.txt")
                return False
                
        except Exception as e:
            self.log_error(f"Error checking Python dependencies: {e}")
            return False

    def check_node_dependencies(self) -> bool:
        """Check if Node.js dependencies are installed."""
        logging.info("🔍 Checking Node.js dependencies...")
        
        if not Path("package.json").exists():
            self.log_error("package.json not found")
            return False
        
        if not Path("node_modules").exists():
            self.log_warning("node_modules directory not found. Attempting to install...")
            install_result = self.run_command(['npm', 'install'], timeout=300)
            if install_result:
                self.log_success("Node.js dependencies installed")
                return True
            else:
                self.log_error("Failed to install Node.js dependencies")
                return False
        else:
            self.log_success("node_modules directory found")
            return True

    def check_system_dependencies(self) -> bool:
        """Check all system dependencies."""
        logging.info("\n--- System Dependency Checks ---")
        
        all_good = True
        
        dependencies = [
            {
                'name': 'Python',
                'command': [sys.executable, '--version'],
                'min_version': '3.8',
                'install': 'Install Python 3.8+ from python.org'
            },
            {
                'name': 'Node.js',
                'command': ['node', '--version'],
                'min_version': '18.0',
                'install': 'Install Node.js 18.0+ from nodejs.org'
            },
            {
                'name': 'npm',
                'command': ['npm', '--version'],
                'min_version': '8.0',
                'install': 'npm comes with Node.js 18.0+'
            },
            {
                'name': 'Nmap',
                'command': ['nmap', '--version'],
                'min_version': '7.0',
                'install': 'Install Nmap: sudo apt install nmap (Linux) or brew install nmap (macOS)'
            }
        ]
        
        for dep in dependencies:
            if not self.check_dependency(dep['name'], dep['command'], dep.get('min_version'), dep.get('install')):
                all_good = False
        
        return all_good

    def check_project_dependencies(self) -> bool:
        """Check project-specific dependencies."""
        logging.info("\n--- Project Dependency Checks ---")
        
        python_ok = self.check_python_dependencies()
        node_ok = self.check_node_dependencies()
        
        return python_ok and node_ok

    def check_backend_server(self) -> bool:
        """Check backend server status and endpoints."""
        logging.info("\n--- Backend Server Checks ---")
        
        backend_running = self.check_port_in_use(self.backend_port)
        if backend_running:
            self.log_success(f"Backend server is running on port {self.backend_port}")
        else:
            self.log_error(f"Backend server is NOT running on port {self.backend_port}")
            logging.info("   Start with: python local_server.py")
            return False

        # Test API endpoints
        endpoints_ok = True
        
        # Test network API
        if not self.check_api_endpoint(f"{self.backend_url}/api/network", name="Network API"):
            endpoints_ok = False
        
        # Test agent status API
        if not self.check_api_endpoint(f"{self.backend_url}/api/agents/status", name="Agent Status API"):
            endpoints_ok = False
        
        # Test insights API with dummy data
        dummy_data = {
            "networkData": {
                "agents": {
                    "127.0.0.1": {
                        "agent_id": "127.0.0.1",
                        "agent_type": "local",
                        "devices": [],
                        "metrics": {"cpu_usage": 0, "memory_total": 0, "memory_used": 0, "memory_free": 0},
                        "timestamp": time.time()
                    }
                },
                "agent_count": 1,
                "local_agent": "127.0.0.1",
                "timestamp": time.time()
            },
            "apiKey": "test_key"
        }
        
        if not self.check_api_endpoint(f"{self.backend_url}/api/insights", method='POST', data=dummy_data, name="AI Insights API"):
            endpoints_ok = False
        
        return endpoints_ok

    def check_frontend_server(self) -> bool:
        """Check frontend server status."""
        logging.info("\n--- Frontend Server Checks ---")
        
        frontend_running = self.check_port_in_use(self.frontend_port)
        if frontend_running:
            self.log_success(f"Frontend server is running on port {self.frontend_port}")
            
            # Check if frontend is responsive
            try:
                response = requests.get(self.frontend_url, timeout=10)
                if response.status_code == 200:
                    self.log_success("Frontend UI is accessible")
                    return True
                else:
                    self.log_error(f"Frontend returned status code: {response.status_code}")
                    return False
            except requests.exceptions.RequestException as e:
                self.log_error(f"Frontend UI is not accessible: {e}")
                return False
        else:
            self.log_error(f"Frontend server is NOT running on port {self.frontend_port}")
            logging.info("   Start with: npm run dev (or python local_server.py)")
            return False

    def check_communication(self) -> bool:
        """Check frontend-backend communication."""
        logging.info("\n--- Frontend-Backend Communication Check ---")
        
        # Check if both servers are running
        backend_running = self.check_port_in_use(self.backend_port)
        frontend_running = self.check_port_in_use(self.frontend_port)
        
        if backend_running and frontend_running:
            self.log_success("Both frontend and backend servers are running")
            
            # Verify .env configuration
            env_file = Path('.env')
            if env_file.exists():
                try:
                    with open(env_file, 'r') as f:
                        content = f.read()
                        if f'VITE_BACKEND_API_URL=http://localhost:{self.backend_port}' in content:
                            self.log_success("Frontend is correctly configured to communicate with backend")
                            return True
                        else:
                            self.log_warning("Frontend backend URL configuration may be incorrect")
                            logging.info(f"   Expected: VITE_BACKEND_API_URL=http://localhost:{self.backend_port}")
                            return True
                except Exception as e:
                    self.log_warning(f"Error reading .env file: {e}")
                    return True
            else:
                self.log_warning(".env file not found, using default configuration")
                return True
        else:
            self.log_warning("Cannot verify frontend-backend communication - one or both servers not running")
            return False

    def check_remote_agent(self) -> bool:
        """Check remote agent functionality."""
        logging.info("\n--- Remote Agent Communication Check ---")
        
        if not self.check_port_in_use(self.backend_port):
            self.log_warning("Backend server not running, skipping remote agent check")
            return False
        
        remote_agent_path = Path("remote_scanner_agent.py")
        if not remote_agent_path.exists():
            self.log_warning(f"remote_scanner_agent.py not found at {remote_agent_path}")
            return False
        
        logging.info("Testing remote scanner agent...")
        agent_command = [
            sys.executable, str(remote_agent_path), 
            '--server', self.backend_url, 
            '--test',
            '--auto-detect'  # Use auto-detect to avoid interactive prompts
        ]
        
        test_result = self.run_command(agent_command, timeout=60)
        if test_result:
            self.log_success("Remote scanner agent test completed successfully")
            time.sleep(2)  # Give backend time to process
            logging.info("   Check 'Agent Management' panel in frontend for remote agent data")
            return True
        else:
            self.log_error("Remote scanner agent test failed")
            return False

    def check_file_structure(self) -> bool:
        """Check if all required files exist."""
        logging.info("\n--- File Structure Checks ---")
        
        required_files = [
            "package.json",
            "server/app.py",
            "server/requirements.txt",
            "local_server.py",
            "remote_scanner_agent.py",
            "src/App.tsx",
            "src/main.tsx",
            "index.html"
        ]
        
        all_files_exist = True
        
        for file_path in required_files:
            if Path(file_path).exists():
                self.log_success(f"Found: {file_path}")
            else:
                self.log_error(f"Missing: {file_path}")
                all_files_exist = False
        
        return all_files_exist

    def check_environment_variables(self) -> bool:
        """Check environment variables and configuration."""
        logging.info("\n--- Environment Configuration Checks ---")
        
        env_file = Path(".env")
        if env_file.exists():
            self.log_success("Found .env file")
            try:
                with open(env_file, 'r') as f:
                    content = f.read()
                    if 'VITE_BACKEND_API_URL' in content:
                        self.log_success("VITE_BACKEND_API_URL configured in .env")
                    else:
                        self.log_warning("VITE_BACKEND_API_URL not found in .env")
                    
                    if 'VITE_PORT' in content:
                        self.log_success("VITE_PORT configured in .env")
                    else:
                        self.log_warning("VITE_PORT not found in .env (will use default)")
                    
                    if 'VITE_SUPABASE_URL' in content:
                        self.log_success("Supabase configuration found in .env")
                    else:
                        self.log_warning("Supabase configuration not found in .env")
            except Exception as e:
                self.log_error(f"Error reading .env file: {e}")
                return False
        else:
            self.log_warning(".env file not found (will be created by local_server.py)")
        
        return True

    def run_comprehensive_check(self) -> bool:
        """Run all health checks."""
        logging.info("🚀 Starting OOX LAB CNS Comprehensive Health Check")
        logging.info("=" * 80)
        
        # File structure check
        self.check_file_structure()
        
        # System dependencies
        self.check_system_dependencies()
        
        # Project dependencies
        self.check_project_dependencies()
        
        # Environment configuration
        self.check_environment_variables()
        
        # Backend server
        self.check_backend_server()
        
        # Frontend server
        self.check_frontend_server()
        
        # Communication
        self.check_communication()
        
        # Remote agent
        self.check_remote_agent()
        
        return self.overall_status

    def print_summary(self):
        """Print a comprehensive summary of the health check."""
        logging.info("\n" + "=" * 80)
        logging.info("HEALTH CHECK SUMMARY")
        logging.info("=" * 80)
        
        if self.overall_status:
            logging.info("🎉 OVERALL STATUS: ALL SYSTEMS NOMINAL!")
            logging.info("✅ Your OOX LAB CNS installation is healthy and ready to use.")
        else:
            logging.error("❌ OVERALL STATUS: ISSUES DETECTED")
            logging.error("⚠️  Your OOX LAB CNS installation has issues that need attention.")
        
        # Configuration summary
        logging.info(f"\n📋 Current Configuration:")
        logging.info(f"   Backend URL: {self.backend_url}")
        logging.info(f"   Frontend URL: {self.frontend_url}")
        
        if self.successes:
            logging.info(f"\n✅ SUCCESSFUL CHECKS ({len(self.successes)}):")
            for success in self.successes[:10]:  # Show first 10
                logging.info(f"   • {success}")
            if len(self.successes) > 10:
                logging.info(f"   ... and {len(self.successes) - 10} more")
        
        if self.warnings:
            logging.info(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for warning in self.warnings:
                logging.warning(f"   • {warning}")
        
        if self.issues:
            logging.info(f"\n❌ ISSUES THAT NEED ATTENTION ({len(self.issues)}):")
            for issue in self.issues:
                logging.error(f"   • {issue}")
        
        logging.info("\n" + "=" * 80)
        logging.info("NEXT STEPS:")
        
        if not self.overall_status:
            logging.info("1. Address the issues listed above")
            logging.info("2. Re-run this health check: python health_check.py")
            logging.info("3. Check the project documentation for troubleshooting")
        else:
            logging.info("1. Your system is ready! Start the application:")
            logging.info("   python local_server.py")
            logging.info(f"2. Open your browser to: {self.frontend_url}")
            logging.info("3. Check the Agent Management panel for remote agents")
        
        logging.info("=" * 80)

def main():
    """Main health check function."""
    try:
        checker = HealthChecker()
        success = checker.run_comprehensive_check()
        checker.print_summary()
        
        # Exit with appropriate code
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        logging.info("\n🛑 Health check cancelled by user")
        sys.exit(1)
    except Exception as e:
        logging.error(f"❌ Unexpected error during health check: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()