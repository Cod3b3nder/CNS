#!/usr/bin/env python3

import sys
import logging
import threading
import time
import subprocess
import signal
import os
import socket
import requests
from datetime import datetime
from pathlib import Path
import queue

# Configure detailed logging with timestamps
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Port configuration constants
DEFAULT_BACKEND_PORT = 5000
DEFAULT_FRONTEND_PORT = 5173
PORT_SCAN_RANGE = 100

# Global variables for process management
frontend_process = None
backend_process = None
shutdown_event = threading.Event()
processes = []
output_threads = []

def get_scan_mode_choice():
    """Get user's choice for scan mode."""
    print("\n" + "="*60)
    print("OOX LAB CNS - Network Scanner Configuration")
    print("="*60)
    print("\nPlease choose your scanning mode:")
    print("\n1. Full Scan")
    print("   - Scans ALL devices on the network")
    print("   - Includes VM NAT IPs, Docker containers, etc.")
    print("   - More comprehensive but may include internal VMs")
    print("\n2. Internet-Facing Scan (Recommended)")
    print("   - Scans only devices that face the internet")
    print("   - Excludes VM NAT IPs and internal containers")
    print("   - Focuses on real network devices and security threats")
    print("\n" + "="*60)
    
    while True:
        try:
            choice = input("Enter your choice (1 or 2): ").strip()
            
            if choice == '1':
                print("\n✅ Selected: Full Scan")
                print("   All network devices will be scanned, including VMs and containers.")
                return "full"
            elif choice == '2':
                print("\n✅ Selected: Internet-Facing Scan")
                print("   Only internet-facing devices will be scanned, VM NAT IPs will be filtered out.")
                return "internet-facing"
            else:
                print("❌ Invalid choice. Please enter 1 or 2.")
                
        except KeyboardInterrupt:
            print("\n\n🛑 Setup cancelled by user")
            sys.exit(1)

def stream_output(process, name, color_code=None):
    """Stream output from a subprocess in real-time."""
    if not process or not process.stdout:
        return
    
    # ANSI color codes for different processes
    colors = {
        'frontend': '\033[94m',  # Blue
        'backend': '\033[92m',   # Green
        'reset': '\033[0m'       # Reset
    }
    
    prefix_color = colors.get(color_code, '')
    reset_color = colors['reset']
    
    try:
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                # Print with colored prefix
                timestamp = datetime.now().strftime('%H:%M:%S')
                print(f"{prefix_color}[{timestamp}] {name}:{reset_color} {output.strip()}")
                sys.stdout.flush()
    except Exception as e:
        logging.error(f"Error streaming output from {name}: {e}")

def check_port_available(port):
    """Check if a port is available for use."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('localhost', port))
            return True
    except socket.error:
        return False

def find_available_port_in_range(default_port):
    """Find an available port in the range [default_port + 1, default_port + PORT_SCAN_RANGE]."""
    for port in range(default_port + 1, default_port + PORT_SCAN_RANGE + 1):
        if check_port_available(port):
            return port
    return None

def update_env_file(backend_port, frontend_port=None):
    """Update the .env file with the new backend URL and frontend port."""
    env_file = Path('.env')
    
    try:
        # Read existing .env file
        if env_file.exists():
            with open(env_file, 'r') as f:
                lines = f.readlines()
        else:
            lines = []
        
        # Update or add VITE_BACKEND_API_URL
        backend_url = f"http://localhost:{backend_port}"
        backend_updated = False
        
        # Update or add VITE_PORT if frontend_port is provided
        frontend_updated = False
        
        for i, line in enumerate(lines):
            if line.startswith('VITE_BACKEND_API_URL='):
                lines[i] = f'VITE_BACKEND_API_URL={backend_url}\n'
                backend_updated = True
            elif frontend_port and line.startswith('VITE_PORT='):
                lines[i] = f'VITE_PORT={frontend_port}\n'
                frontend_updated = True
        
        if not backend_updated:
            lines.append(f'VITE_BACKEND_API_URL={backend_url}\n')
        
        if frontend_port and not frontend_updated:
            lines.append(f'VITE_PORT={frontend_port}\n')
        
        # Write back to .env file
        with open(env_file, 'w') as f:
            f.writelines(lines)
        
        logging.info(f"✅ Updated .env file with backend URL: {backend_url}")
        if frontend_port:
            logging.info(f"✅ Updated .env file with frontend port: {frontend_port}")
        
    except Exception as e:
        logging.error(f"❌ Failed to update .env file: {e}")

def get_and_set_port(default_port, service_name, is_backend=False):
    """
    Determine the port to use for a service, handling conflicts automatically.
    Returns the port to use or None if user cancels.
    """
    if check_port_available(default_port):
        logging.info(f"✅ Port {default_port} is available for {service_name}")
        return default_port
    
    logging.warning(f"⚠️  Port {default_port} is in use. Scanning for alternative ports...")
    
    # Try to find an alternative port
    alternative_port = find_available_port_in_range(default_port)
    
    if alternative_port:
        logging.warning(f"⚠️  Port {default_port} is in use. Using alternative port {alternative_port} for {service_name}")
        
        if is_backend:
            update_env_file(alternative_port)
        
        logging.info(f"✅ Successfully configured {service_name} to use port {alternative_port}")
        return alternative_port
    
    # No available ports found in range
    logging.error(f"❌ No available ports found in range {default_port + 1}-{default_port + PORT_SCAN_RANGE}")
    logging.error(f"❌ Unable to start {service_name} automatically")
    
    print(f"\n{'='*60}")
    print(f"PORT CONFLICT RESOLUTION REQUIRED")
    print(f"{'='*60}")
    print(f"Service: {service_name}")
    print(f"Default port {default_port} is in use")
    print(f"No alternative ports available in range {default_port + 1}-{default_port + PORT_SCAN_RANGE}")
    print(f"\nOptions:")
    print(f"1. Manually specify a port number")
    print(f"2. Close conflicting processes using port {default_port}")
    print(f"3. Cancel installation")
    print(f"{'='*60}")
    
    while True:
        try:
            choice = input("Enter your choice (1/2/3): ").strip()
            
            if choice == '1':
                # Manual port specification
                while True:
                    try:
                        manual_port = int(input(f"Enter port number for {service_name}: "))
                        if 1024 <= manual_port <= 65535:
                            if check_port_available(manual_port):
                                logging.info(f"✅ Using manually specified port {manual_port} for {service_name}")
                                if is_backend:
                                    update_env_file(manual_port)
                                return manual_port
                            else:
                                print(f"❌ Port {manual_port} is also in use. Please try another port.")
                        else:
                            print("❌ Port must be between 1024 and 65535")
                    except ValueError:
                        print("❌ Please enter a valid port number")
            
            elif choice == '2':
                # Guide user to close conflicting processes
                print(f"\nTo free up port {default_port}, you can:")
                print(f"Windows: netstat -ano | findstr :{default_port}")
                print(f"         taskkill /PID <PID> /F")
                print(f"macOS/Linux: lsof -ti:{default_port} | xargs kill -9")
                print(f"\nAfter closing the conflicting process, press Enter to retry...")
                input()
                
                if check_port_available(default_port):
                    logging.info(f"✅ Port {default_port} is now available for {service_name}")
                    return default_port
                else:
                    print(f"❌ Port {default_port} is still in use")
            
            elif choice == '3':
                # Cancel installation
                logging.info("🛑 Installation cancelled by user")
                return None
            
            else:
                print("❌ Invalid choice. Please enter 1, 2, or 3")
                
        except KeyboardInterrupt:
            logging.info("\n🛑 Installation cancelled by user")
            return None

def wait_for_server(url, timeout=30, name="Server"):
    """Wait for a server to become responsive."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                logging.info(f"✅ {name} is responsive at {url}")
                return True
        except requests.exceptions.RequestException:
            pass
        time.sleep(2)
    
    logging.error(f"❌ {name} failed to become responsive within {timeout} seconds")
    return False

def check_system_dependencies():
    """Check if required system dependencies are installed."""
    logging.info("🔍 Checking system dependencies...")
    
    dependencies = {
        'python': {'cmd': [sys.executable, '--version'], 'min_version': '3.8'},
        'node': {'cmd': ['node', '--version'], 'min_version': '18.0'},
        'npm': {'cmd': ['npm', '--version'], 'min_version': '8.0'},
        'nmap': {'cmd': ['nmap', '--version'], 'min_version': '7.0'}
    }
    
    missing_deps = []
    
    for dep_name, dep_info in dependencies.items():
        try:
            result = subprocess.run(dep_info['cmd'], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                logging.info(f"✅ {dep_name} is installed")
            else:
                missing_deps.append(dep_name)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            missing_deps.append(dep_name)
    
    if missing_deps:
        logging.error(f"❌ Missing dependencies: {', '.join(missing_deps)}")
        logging.error("Please install the missing dependencies and try again.")
        if 'nmap' in missing_deps:
            logging.error("Install Nmap from: https://nmap.org/download.html")
        return False
    
    logging.info("✅ All system dependencies are satisfied")
    return True

def install_python_dependencies():
    """Install Python dependencies from requirements.txt."""
    logging.info("📦 Installing Python dependencies...")
    
    requirements_file = Path("server/requirements.txt")
    if not requirements_file.exists():
        logging.error("❌ server/requirements.txt not found")
        return False
    
    try:
        # Check if pip is available
        subprocess.run([sys.executable, '-m', 'pip', '--version'], 
                      capture_output=True, check=True, timeout=10)
        
        # Install dependencies
        result = subprocess.run([
            sys.executable, '-m', 'pip', 'install', '-r', str(requirements_file)
        ], capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            logging.info("✅ Python dependencies installed successfully")
            return True
        else:
            logging.error(f"❌ Failed to install Python dependencies: {result.stderr}")
            return False
            
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError, FileNotFoundError) as e:
        logging.error(f"❌ Error installing Python dependencies: {e}")
        return False

def open_browser(url):
    """Open the URL in the default web browser."""
    try:
        logging.info(f"🌐 Opening browser to {url}...")
        subprocess.run(['xdg-open', url], check=True, timeout=10)
        logging.info("✅ Browser opened successfully")
        return True
    except subprocess.CalledProcessError as e:
        logging.warning(f"⚠️  Failed to open browser automatically: {e}")
        logging.info(f"📋 Please manually open your browser and navigate to: {url}")
        return False
    except subprocess.TimeoutExpired:
        logging.warning("⚠️  Browser opening timed out")
        logging.info(f"📋 Please manually open your browser and navigate to: {url}")
        return False
    except FileNotFoundError:
        logging.warning("⚠️  xdg-open command not found")
        logging.info(f"📋 Please manually open your browser and navigate to: {url}")
        return False
    except Exception as e:
        logging.warning(f"⚠️  Unexpected error opening browser: {e}")
        logging.info(f"📋 Please manually open your browser and navigate to: {url}")
        return False

def start_frontend_server(port, backend_port):
    """Start the frontend development server on the specified port with backend URL."""
    global frontend_process
    
    logging.info(f"🌐 Starting frontend server on port {port}...")
    
    try:
        # Set environment variables for the frontend
        env = os.environ.copy()
        env['VITE_PORT'] = str(port)
        # CRITICAL: Pass the backend URL to the frontend
        env['VITE_BACKEND_API_URL'] = f"http://localhost:{backend_port}"
        
        logging.info(f"🔗 Frontend configured to connect to backend at: http://localhost:{backend_port}")
        
        # Start the frontend server with real-time output streaming
        frontend_process = subprocess.Popen(
            ['npm', 'run', 'dev'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
            env=env
        )
        
        processes.append(frontend_process)
        
        # Start output streaming thread
        output_thread = threading.Thread(
            target=stream_output, 
            args=(frontend_process, "FRONTEND", "frontend"),
            daemon=True
        )
        output_thread.start()
        output_threads.append(output_thread)
        
        logging.info(f"🚀 Frontend server process started on port {port}")
        
        # Wait for server to become responsive
        frontend_url = f"http://localhost:{port}"
        if wait_for_server(frontend_url, timeout=60, name="Frontend server"):
            # Open browser automatically after server is ready
            open_browser(frontend_url)
            return True
        else:
            logging.error("❌ Frontend server failed to start properly")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to start frontend server: {e}")
        return False

def start_backend_server(port, scan_mode):
    """Start the backend server on the specified port with scan mode."""
    global backend_process
    
    logging.info(f"🖥️  Starting backend server on port {port} (scan mode: {scan_mode})...")
    
    try:
        # Set environment variables for the backend
        env = os.environ.copy()
        env['BACKEND_PORT'] = str(port)
        env['SCAN_MODE'] = scan_mode
        
        # Start the backend server with real-time output streaming
        backend_process = subprocess.Popen(
            [sys.executable, 'server/app.py'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
            env=env
        )
        
        processes.append(backend_process)
        
        # Start output streaming thread
        output_thread = threading.Thread(
            target=stream_output, 
            args=(backend_process, "BACKEND", "backend"),
            daemon=True
        )
        output_thread.start()
        output_threads.append(output_thread)
        
        logging.info(f"🚀 Backend server process started on port {port}")
        
        # Wait for server to become responsive
        if wait_for_server(f"http://localhost:{port}/api/network", timeout=30, name="Backend server"):
            return True
        else:
            logging.error("❌ Backend server failed to start properly")
            return False
            
    except Exception as e:
        logging.error(f"❌ Failed to start backend server: {e}")
        return False

def monitor_system_status():
    """Monitor both servers and system resources."""
    logging.info("📊 Starting system monitoring...")
    
    # Try to import psutil for system monitoring
    try:
        import psutil
        psutil_available = True
    except ImportError:
        psutil_available = False
        logging.warning("⚠️  psutil not available - system metrics will be limited")
    
    while not shutdown_event.is_set():
        try:
            # Check server processes
            if frontend_process and frontend_process.poll() is not None:
                logging.error("❌ Frontend server process has terminated")
            
            if backend_process and backend_process.poll() is not None:
                logging.error("❌ Backend server process has terminated")
            
            # System resource monitoring
            if psutil_available:
                cpu_percent = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                
                logging.info(f"📊 System Status - CPU: {cpu_percent:.1f}%, Memory: {memory.percent:.1f}% used")
                
                if cpu_percent > 80:
                    logging.warning(f"⚠️  High CPU usage: {cpu_percent:.1f}%")
                if memory.percent > 80:
                    logging.warning(f"⚠️  High memory usage: {memory.percent:.1f}%")
            
            # Wait before next check
            shutdown_event.wait(30)  # Check every 30 seconds
            
        except Exception as e:
            logging.error(f"❌ Error in system monitoring: {e}")
            shutdown_event.wait(10)

def signal_handler(signum, frame):
    """Handle shutdown signals."""
    logging.info(f"🛑 Received signal {signum}, initiating shutdown...")
    shutdown_event.set()

def cleanup_processes():
    """Clean up all started processes."""
    logging.info("🧹 Cleaning up processes...")
    
    for process in processes:
        if process and process.poll() is None:
            try:
                logging.info(f"🛑 Terminating process {process.pid}")
                process.terminate()
                
                # Wait for graceful termination
                try:
                    process.wait(timeout=10)
                    logging.info(f"✅ Process {process.pid} terminated gracefully")
                except subprocess.TimeoutExpired:
                    logging.warning(f"⚠️  Process {process.pid} did not terminate gracefully, forcing kill")
                    process.kill()
                    process.wait()
                    
            except Exception as e:
                logging.error(f"❌ Error terminating process {process.pid}: {e}")

def main():
    """Initialize and manage both servers with proper error handling and port conflict resolution."""
    logging.info("🚀 Starting OOX LAB CNS Local Development Environment")
    logging.info("=" * 60)
    
    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # Get scan mode choice from user
        scan_mode = get_scan_mode_choice()
        
        # Check system dependencies
        if not check_system_dependencies():
            sys.exit(1)
        
        # Install Python dependencies
        if not install_python_dependencies():
            sys.exit(1)
        
        # Determine ports for both services
        logging.info("🔍 Checking port availability...")
        
        backend_port = get_and_set_port(DEFAULT_BACKEND_PORT, "Backend Server", is_backend=True)
        if backend_port is None:
            sys.exit(1)
        
        frontend_port = get_and_set_port(DEFAULT_FRONTEND_PORT, "Frontend Server", is_backend=False)
        if frontend_port is None:
            sys.exit(1)
        
        # Update .env file with both ports
        update_env_file(backend_port, frontend_port)
        
        # Log configuration summary
        logging.info("📋 Configuration Summary:")
        logging.info(f"   Scan Mode: {scan_mode}")
        logging.info(f"   Backend Server: {backend_port}")
        logging.info(f"   Frontend Server: {frontend_port}")
        
        # Start backend server first
        if not start_backend_server(backend_port, scan_mode):
            logging.error("❌ Failed to start backend server")
            sys.exit(1)
        
        # Start frontend server with backend URL
        if not start_frontend_server(frontend_port, backend_port):
            logging.error("❌ Failed to start frontend server")
            cleanup_processes()
            sys.exit(1)
        
        # Start monitoring in a separate thread
        monitor_thread = threading.Thread(target=monitor_system_status, daemon=True)
        monitor_thread.start()
        
        # Display success message
        logging.info("=" * 60)
        logging.info("🎉 OOX LAB CNS Development Environment Started Successfully!")
        logging.info(f"📱 Frontend: http://localhost:{frontend_port}")
        logging.info(f"🔧 Backend API: http://localhost:{backend_port}")
        logging.info(f"📊 Network Scanner: http://localhost:{backend_port}/api/network")
        logging.info(f"🔍 Scan Mode: {scan_mode.upper()}")
        logging.info("=" * 60)
        logging.info("Press Ctrl+C to stop all servers")
        logging.info("=" * 60)
        
        # Keep the main thread alive
        while not shutdown_event.is_set():
            shutdown_event.wait(1)
            
    except KeyboardInterrupt:
        logging.info("🛑 Keyboard interrupt received")
    except Exception as e:
        logging.error(f"❌ Unexpected error: {e}")
    finally:
        # Cleanup
        shutdown_event.set()
        cleanup_processes()
        logging.info("👋 OOX LAB CNS Development Environment stopped")

if __name__ == '__main__':
    main()