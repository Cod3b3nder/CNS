import http.server
import socketserver
import json
import os
import socket
import struct
import threading
import time
import logging
import platform
import nmap
from pathlib import Path
from typing import Dict, List, Any
import ipaddress

# Try to import psutil with fallback metrics
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    logging.warning("psutil not available. Using fallback system metrics.")
    PSUTIL_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('network_monitor.log'),
        logging.StreamHandler()
    ]
)

# VM NAT IP ranges to filter out when using internet-facing mode
VM_NAT_PRIVATE_RANGES = [
    ipaddress.ip_network('172.16.0.0/12'),    # Docker default bridge
    ipaddress.ip_network('192.168.122.0/24'), # KVM/libvirt default
    ipaddress.ip_network('192.168.99.0/24'),  # Docker Machine
    ipaddress.ip_network('10.0.2.0/24'),      # VirtualBox NAT default
    ipaddress.ip_network('172.17.0.0/16'),    # Docker bridge networks
    ipaddress.ip_network('172.18.0.0/16'),    # Docker bridge networks
    ipaddress.ip_network('172.19.0.0/16'),    # Docker bridge networks
    ipaddress.ip_network('172.20.0.0/16'),    # Docker bridge networks
    ipaddress.ip_network('192.168.64.0/24'),  # VMware Fusion NAT
    ipaddress.ip_network('192.168.56.0/24'),  # VirtualBox Host-Only
    ipaddress.ip_network('192.168.57.0/24'),  # VirtualBox Host-Only
    ipaddress.ip_network('192.168.58.0/24'),  # VirtualBox Host-Only
    ipaddress.ip_network('10.211.55.0/24'),   # Parallels NAT
    ipaddress.ip_network('10.37.129.0/24'),   # Parallels Shared
]

def is_private_vm_nat_ip(ip_address: str) -> bool:
    """Check if an IP address falls within common VM NAT private ranges."""
    try:
        ip = ipaddress.ip_address(ip_address)
        for network in VM_NAT_PRIVATE_RANGES:
            if ip in network:
                return True
        return False
    except ValueError:
        return False

# Device identification based on MAC address prefixes (OUI)
DEVICE_MANUFACTURERS = {
    # Apple devices
    '00:03:93': 'Apple',
    '00:05:02': 'Apple',
    '00:0A:27': 'Apple',
    '00:0A:95': 'Apple',
    '00:1B:63': 'Apple',
    '00:1E:52': 'Apple',
    '00:1F:5B': 'Apple',
    '00:1F:F3': 'Apple',
    '00:21:E9': 'Apple',
    '00:22:41': 'Apple',
    '00:23:12': 'Apple',
    '00:23:32': 'Apple',
    '00:24:36': 'Apple',
    '00:25:00': 'Apple',
    '00:26:08': 'Apple',
    '00:26:B0': 'Apple',
    '00:26:BB': 'Apple',
    '00:30:65': 'Apple',
    
    # Samsung devices
    '00:07:AB': 'Samsung',
    '00:12:47': 'Samsung',
    '00:15:99': 'Samsung',
    '00:17:C9': 'Samsung',
    '00:1C:43': 'Samsung',
    '00:21:19': 'Samsung',
    '00:23:39': 'Samsung',
    '00:24:54': 'Samsung',
    '00:26:37': 'Samsung',
    
    # Printers
    '00:00:AA': 'Xerox',
    '00:00:17': 'Epson',
    '00:01:E6': 'Hewlett-Packard',
    '00:02:B3': 'Intel',
    '00:04:EA': 'Hewlett-Packard',
    '00:08:C7': 'Hewlett-Packard',
    '00:0B:CD': 'Hewlett-Packard',
    '00:0F:61': 'Hewlett-Packard',
    '00:11:0A': 'Hewlett-Packard',
    '00:13:21': 'Hewlett-Packard',
    
    # Smart TVs
    '00:12:FB': 'Samsung Electronics',
    '08:00:28': 'Texas Instruments',
    '00:1A:11': 'Google',
    '00:1E:45': 'Sony',
    '00:26:75': 'Sony',
    
    # IoT and Smart Home
    '00:17:88': 'Philips Lighting',
    '00:24:E4': 'Withings',
    'D0:52:A8': 'Physical Web',
    '44:65:0D': 'Amazon',
    
    # Network equipment
    '00:06:25': 'Linksys',
    '00:18:F8': 'Cisco-Linksys',
    '00:14:BF': 'Cisco-Linksys',
    '00:1A:70': 'Cisco-Linksys',
    '00:21:29': 'Cisco-Linksys',
    '00:23:69': 'Cisco-Linksys',
    '00:25:9C': 'Cisco-Linksys',
}

# Device type identification based on ports and services
DEVICE_SIGNATURES = {
    'printer': {
        'ports': [631, 9100],
        'services': ['ipp', 'jetdirect', 'printer'],
    },
    'smart_tv': {
        'ports': [3000, 5000, 8008, 8009],
        'services': ['pnp', 'dlna', 'roku'],
    },
    'smartphone': {
        'ports': [62078, 5353],
        'services': ['lockdownd', 'mdns'],
    },
    'iot_device': {
        'ports': [1883, 8883],
        'services': ['mqtt', 'coap'],
    },
    'camera': {
        'ports': [554, 8000, 8080],
        'services': ['rtsp', 'hikvision', 'onvif'],
    },
    'game_console': {
        'ports': [3074, 3075, 3076],
        'services': ['xbox', 'playstation'],
    },
}

def generate_ai_insights(network_data: Dict[str, Any], api_key: str = None) -> List[Dict[str, Any]]:
    """
    Generate AI-powered security insights based on network data.
    This is a placeholder implementation that simulates AI analysis.
    In production, this would integrate with actual AI services like OpenAI, Google AI, etc.
    """
    insights = []
    
    try:
        # Collect all devices from all agents
        all_devices = []
        for agent_data in network_data.get('agents', {}).values():
            all_devices.extend(agent_data.get('devices', []))
        
        if not all_devices:
            return [{
                'severity': 'low',
                'title': 'No Network Devices Detected',
                'description': 'No devices were found during the network scan. This could indicate network connectivity issues or restrictive firewall settings.',
                'recommendation': 'Verify network connectivity and ensure the scanner has appropriate permissions to discover devices.'
            }]
        
        # Analyze device statuses
        compromised_devices = [d for d in all_devices if d.get('status') == 'compromised']
        warning_devices = [d for d in all_devices if d.get('status') == 'warning']
        safe_devices = [d for d in all_devices if d.get('status') == 'safe']
        
        # Critical insights for compromised devices
        if compromised_devices:
            insights.append({
                'severity': 'critical',
                'title': 'Critical Security Breach Detected',
                'description': f'Found {len(compromised_devices)} compromised device(s) on the network. These devices show signs of potential security breaches or suspicious activity.',
                'recommendation': 'Immediately isolate affected devices, run comprehensive security scans, and investigate potential data breaches. Consider resetting credentials and updating security policies.'
            })
            
            # Analyze specific compromised devices
            for device in compromised_devices[:3]:  # Limit to first 3 for brevity
                open_ports = [p for p in device.get('ports', []) if p.get('state') == 'open']
                insights.append({
                    'severity': 'high',
                    'title': f'Compromised Device: {device.get("hostname", device.get("ip"))}',
                    'description': f'Device {device.get("ip")} ({device.get("hostname")}) has {len(open_ports)} open ports and shows signs of compromise.',
                    'recommendation': f'Disconnect device {device.get("ip")} from the network immediately and perform forensic analysis.'
                })
        
        # High severity for warning devices
        if warning_devices:
            insights.append({
                'severity': 'high',
                'title': 'Suspicious Network Activity',
                'description': f'Detected {len(warning_devices)} device(s) with suspicious activity or unusual port configurations.',
                'recommendation': 'Monitor these devices closely, review their network traffic, and consider implementing additional security measures.'
            })
        
        # Analyze open ports across all devices
        all_open_ports = []
        for device in all_devices:
            for port in device.get('ports', []):
                if port.get('state') == 'open':
                    all_open_ports.append(port.get('port'))
        
        # Check for risky services
        risky_ports = {21: 'FTP', 22: 'SSH', 23: 'Telnet', 135: 'RPC', 139: 'NetBIOS', 445: 'SMB', 3389: 'RDP'}
        found_risky_ports = {port: service for port, service in risky_ports.items() if port in all_open_ports}
        
        if found_risky_ports:
            insights.append({
                'severity': 'medium',
                'title': 'Potentially Risky Services Detected',
                'description': f'Found potentially risky services running: {", ".join([f"{service} (port {port})" for port, service in found_risky_ports.items()])}',
                'recommendation': 'Review the necessity of these services, ensure they are properly secured with strong authentication, and consider restricting access through firewall rules.'
            })
        
        # Analyze device types for IoT security
        iot_devices = [d for d in all_devices if d.get('device_type') in ['iot_device', 'camera', 'smart_tv']]
        if iot_devices:
            insights.append({
                'severity': 'medium',
                'title': 'IoT Devices Require Security Review',
                'description': f'Found {len(iot_devices)} IoT device(s) on the network. IoT devices are often targets for attackers due to weak default security.',
                'recommendation': 'Ensure all IoT devices have updated firmware, changed default passwords, and are on a separate network segment if possible.'
            })
        
        # Network segmentation analysis
        unique_networks = set()
        for agent_data in network_data.get('agents', {}).values():
            network_range = agent_data.get('network_range')
            if network_range:
                unique_networks.add(network_range)
        
        if len(unique_networks) == 1 and len(all_devices) > 10:
            insights.append({
                'severity': 'medium',
                'title': 'Network Segmentation Recommended',
                'description': f'All {len(all_devices)} devices are on the same network segment. This increases security risks if one device is compromised.',
                'recommendation': 'Consider implementing network segmentation to isolate different types of devices (e.g., IoT devices, servers, workstations) into separate VLANs.'
            })
        
        # Positive insights for good security posture
        if len(compromised_devices) == 0 and len(warning_devices) == 0:
            insights.append({
                'severity': 'low',
                'title': 'Good Security Posture',
                'description': f'No immediate security threats detected across {len(all_devices)} scanned devices. All devices appear to be in a safe state.',
                'recommendation': 'Continue regular security monitoring and maintain current security practices. Consider periodic penetration testing to validate security measures.'
            })
        
        # Agent analysis
        agent_count = network_data.get('agent_count', 0)
        if agent_count > 1:
            insights.append({
                'severity': 'low',
                'title': 'Distributed Monitoring Active',
                'description': f'Network monitoring is distributed across {agent_count} agents, providing comprehensive coverage.',
                'recommendation': 'Ensure all monitoring agents are kept up to date and have consistent security policies applied.'
            })
        
        # If API key is provided, add a note about AI enhancement
        if api_key and len(api_key.strip()) > 0:
            insights.append({
                'severity': 'low',
                'title': 'AI-Enhanced Analysis Available',
                'description': 'API key configured for enhanced AI analysis. Note: This is currently a simulated analysis for demonstration purposes.',
                'recommendation': 'In production, this would integrate with services like OpenAI GPT, Google AI, or other security analysis platforms for deeper insights.'
            })
        
    except Exception as e:
        logging.error(f"Error generating AI insights: {e}")
        insights.append({
            'severity': 'medium',
            'title': 'Analysis Error',
            'description': f'An error occurred during security analysis: {str(e)}',
            'recommendation': 'Check system logs and ensure network data is properly formatted.'
        })
    
    return insights

class NetworkAggregator:
    def __init__(self, scan_mode: str = "internet-facing"):
        self.last_scan = 0
        self.scan_interval = 30  # seconds
        self.rate_limit = 100  # requests per scan
        self.scan_mode = scan_mode
        self._lock = threading.Lock()
        self._cache = {}
        self.nm = nmap.PortScanner()
        self.is_scanning = False
        
        # New data structure for aggregated scans
        self.all_scans = {}
        self.local_ip = self.get_local_ip()
        
        # Remote agent management
        self.registered_agents = {}  # agent_id -> {ip, last_seen, status}
        self.agent_timeout = 300  # 5 minutes timeout for agents
        
        logging.info(f"NetworkAggregator initialized with scan mode: {self.scan_mode}")

    def get_local_ip(self) -> str:
        """Get the local machine's IP address."""
        try:
            # Connect to a remote address to determine local IP
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except Exception:
            return "127.0.0.1"

    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system metrics with fallback if psutil is not available."""
        try:
            if PSUTIL_AVAILABLE:
                cpu_usage = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                return {
                    'cpu_usage': cpu_usage,
                    'memory_total': memory.total,
                    'memory_used': memory.used,
                    'memory_free': memory.available,
                    'disk_total': disk.total,
                    'disk_used': disk.used,
                    'disk_free': disk.free
                }
            else:
                # Fallback metrics
                return {
                    'cpu_usage': 0,
                    'memory_total': 8 * 1024 * 1024 * 1024,  # 8GB placeholder
                    'memory_used': 4 * 1024 * 1024 * 1024,   # 4GB placeholder
                    'memory_free': 4 * 1024 * 1024 * 1024,   # 4GB placeholder
                    'disk_total': 500 * 1024 * 1024 * 1024,  # 500GB placeholder
                    'disk_used': 250 * 1024 * 1024 * 1024,   # 250GB placeholder
                    'disk_free': 250 * 1024 * 1024 * 1024    # 250GB placeholder
                }
        except Exception as e:
            logging.error(f"Error getting system metrics: {e}")
            return {
                'cpu_usage': 0,
                'memory_total': 0,
                'memory_used': 0,
                'memory_free': 0,
                'disk_total': 0,
                'disk_used': 0,
                'disk_free': 0
            }

    def identify_device_type(self, mac_address: str, ports: List[Dict], hostname: str) -> Dict[str, str]:
        """Identify device type based on MAC address, ports, and hostname."""
        mac_prefix = mac_address[:8].upper()
        manufacturer = DEVICE_MANUFACTURERS.get(mac_prefix, 'Unknown')
        
        # Initialize device info
        device_info = {
            'manufacturer': manufacturer,
            'type': 'unknown',
            'model': 'unknown'
        }
        
        # Check ports against device signatures
        port_numbers = [p['port'] for p in ports]
        services = [p.get('service', '').lower() for p in ports]
        
        for device_type, signature in DEVICE_SIGNATURES.items():
            if any(port in signature['ports'] for port in port_numbers) or \
               any(service in signature['services'] for service in services):
                device_info['type'] = device_type
                break
        
        # Additional identification based on hostname and manufacturer
        hostname_lower = hostname.lower()
        if 'printer' in hostname_lower or manufacturer in ['Xerox', 'Epson', 'Hewlett-Packard']:
            device_info['type'] = 'printer'
        elif 'tv' in hostname_lower or manufacturer in ['Samsung Electronics', 'Sony', 'LG']:
            device_info['type'] = 'smart_tv'
        elif 'phone' in hostname_lower or manufacturer in ['Apple', 'Samsung']:
            device_info['type'] = 'smartphone'
        elif 'camera' in hostname_lower:
            device_info['type'] = 'camera'
        elif manufacturer in ['Philips Lighting', 'Physical Web', 'Amazon']:
            device_info['type'] = 'iot_device'
        
        return device_info

    def get_network_range(self) -> str:
        """Get the local network range."""
        try:
            # Get the default network interface
            if platform.system() == "Windows":
                interface = next((i for i in psutil.net_if_addrs() if "Ethernet" in i or "Wi-Fi" in i), None)
            else:
                interface = next((i for i in psutil.net_if_addrs() if i != "lo"), None)
            
            if not interface:
                raise ValueError("No suitable network interface found")

            # Get the IP address and netmask
            addrs = psutil.net_if_addrs()[interface]
            ip_info = next((addr for addr in addrs if addr.family == socket.AF_INET), None)
            
            if not ip_info:
                raise ValueError("No IPv4 address found")

            # Calculate network range
            ip_parts = ip_info.address.split('.')
            return f"{'.'.join(ip_parts[:-1])}.0/24"
            
        except Exception as e:
            logging.error(f"Error getting network range: {e}")
            return "192.168.1.0/24"  # Fallback to common local network

    def perform_nmap_scan(self, target: str) -> Dict[str, Any]:
        """Perform detailed Nmap scan on a target."""
        try:
            # Perform OS and version detection
            self.nm.scan(target, arguments='-sS -sV -O --version-intensity 5')
            
            if target not in self.nm.all_hosts():
                return None

            host_info = self.nm[target]
            
            # Get MAC address if available
            mac_address = host_info.get('addresses', {}).get('mac', '')
            
            # Extract OS details
            os_info = {
                'name': 'Unknown',
                'accuracy': 0,
                'family': 'Unknown'
            }
            
            if 'osmatch' in host_info and host_info['osmatch']:
                best_match = host_info['osmatch'][0]
                os_info = {
                    'name': best_match['name'],
                    'accuracy': best_match['accuracy'],
                    'family': best_match['osclass'][0]['osfamily'] if best_match.get('osclass') else 'Unknown'
                }

            # Extract port and service information
            ports_info = []
            if 'tcp' in host_info:
                for port, data in host_info['tcp'].items():
                    ports_info.append({
                        'port': port,
                        'state': data['state'],
                        'service': data['name'],
                        'version': data.get('version', ''),
                        'product': data.get('product', '')
                    })

            # Identify device type
            device_info = self.identify_device_type(mac_address, ports_info, socket.getfqdn(target))

            # Determine device status based on open ports and services
            status = 'safe'
            suspicious_ports = {21, 22, 23, 3389}  # FTP, SSH, Telnet, RDP
            open_suspicious = any(p['port'] in suspicious_ports and p['state'] == 'open' for p in ports_info)
            
            if open_suspicious:
                status = 'warning'
            if len([p for p in ports_info if p['state'] == 'open']) > 5:
                status = 'compromised'

            return {
                'ip': target,
                'hostname': socket.getfqdn(target),
                'mac_address': mac_address,
                'manufacturer': device_info['manufacturer'],
                'device_type': device_info['type'],
                'model': device_info['model'],
                'os': os_info,
                'ports': ports_info,
                'status': status,
                'last_seen': time.time()
            }
            
        except Exception as e:
            logging.error(f"Error during Nmap scan of {target}: {e}")
            return None

    def scan_network(self) -> Dict[str, Any]:
        """Perform local network scan and store in all_scans."""
        if not self.is_scanning:
            return self.get_aggregated_data()

        current_time = time.time()
        
        # Rate limiting
        if current_time - self.last_scan < self.scan_interval:
            return self.get_aggregated_data()
            
        with self._lock:
            try:
                devices = []
                network_range = self.get_network_range()
                
                # Perform initial fast ping scan
                logging.info(f"Starting ping scan on {network_range} (mode: {self.scan_mode})")
                self.nm.scan(hosts=network_range, arguments='-sn')
                hosts = self.nm.all_hosts()
                
                # Detailed scan of discovered hosts
                scanned_count = 0
                filtered_count = 0
                
                for host in hosts:
                    if scanned_count >= self.rate_limit:
                        break
                        
                    try:
                        # Apply VM NAT filtering if in internet-facing mode
                        if self.scan_mode == "internet-facing" and is_private_vm_nat_ip(host):
                            logging.debug(f"Skipping VM NAT IP {host} (internet-facing mode)")
                            filtered_count += 1
                            continue
                        
                        scan_result = self.perform_nmap_scan(host)
                        if scan_result:
                            devices.append(scan_result)
                            scanned_count += 1
                            
                    except Exception as e:
                        logging.error(f"Error scanning host {host}: {e}")
                        continue
                
                if filtered_count > 0:
                    logging.info(f"Filtered out {filtered_count} VM NAT IPs in internet-facing mode")
                
                # Store local scan results
                local_scan_data = {
                    'agent_id': self.local_ip,
                    'agent_type': 'local',
                    'devices': devices,
                    'metrics': self.get_system_metrics(),
                    'timestamp': current_time,
                    'scanning': self.is_scanning,
                    'network_range': network_range,
                    'scan_mode': self.scan_mode,
                    'filtered_vm_ips': filtered_count
                }
                
                self.all_scans[self.local_ip] = local_scan_data
                self.last_scan = current_time
                
                return self.get_aggregated_data()
                
            except Exception as e:
                logging.error(f"Error during network scan: {e}")
                return self.get_aggregated_data()

    def receive_remote_scan(self, agent_ip: str, scan_data: Dict[str, Any]) -> bool:
        """Receive and store scan data from remote agents."""
        try:
            current_time = time.time()
            
            # Validate scan data structure
            required_fields = ['devices', 'metrics', 'timestamp']
            if not all(field in scan_data for field in required_fields):
                logging.error(f"Invalid scan data from {agent_ip}: missing required fields")
                return False
            
            # Add agent metadata
            scan_data['agent_id'] = agent_ip
            scan_data['agent_type'] = 'remote'
            scan_data['received_at'] = current_time
            
            # Store the scan data
            with self._lock:
                self.all_scans[agent_ip] = scan_data
                
                # Update agent registry
                self.registered_agents[agent_ip] = {
                    'ip': agent_ip,
                    'last_seen': current_time,
                    'status': 'active'
                }
            
            scan_mode = scan_data.get('scan_mode', 'unknown')
            filtered_count = scan_data.get('filtered_vm_ips', 0)
            logging.info(f"Received scan data from remote agent {agent_ip} (mode: {scan_mode}, filtered: {filtered_count})")
            return True
            
        except Exception as e:
            logging.error(f"Error processing remote scan from {agent_ip}: {e}")
            return False

    def cleanup_stale_agents(self):
        """Remove stale agent data."""
        current_time = time.time()
        stale_agents = []
        
        with self._lock:
            for agent_id, agent_info in self.registered_agents.items():
                if current_time - agent_info['last_seen'] > self.agent_timeout:
                    stale_agents.append(agent_id)
            
            for agent_id in stale_agents:
                if agent_id in self.all_scans:
                    del self.all_scans[agent_id]
                if agent_id in self.registered_agents:
                    del self.registered_agents[agent_id]
                logging.info(f"Removed stale agent: {agent_id}")

    def get_aggregated_data(self) -> Dict[str, Any]:
        """Return aggregated data from all scanning sources."""
        self.cleanup_stale_agents()
        
        with self._lock:
            return {
                'agents': dict(self.all_scans),
                'agent_count': len(self.all_scans),
                'local_agent': self.local_ip,
                'scan_mode': self.scan_mode,
                'timestamp': time.time()
            }

    def get_agent_status(self) -> Dict[str, Any]:
        """Get status of all registered agents."""
        current_time = time.time()
        agent_status = {}
        
        with self._lock:
            for agent_id, scan_data in self.all_scans.items():
                agent_info = self.registered_agents.get(agent_id, {})
                last_seen = agent_info.get('last_seen', scan_data.get('timestamp', 0))
                
                agent_status[agent_id] = {
                    'type': scan_data.get('agent_type', 'unknown'),
                    'last_seen': last_seen,
                    'status': 'active' if current_time - last_seen < self.agent_timeout else 'stale',
                    'device_count': len(scan_data.get('devices', [])),
                    'network_range': scan_data.get('network_range', 'unknown'),
                    'scan_mode': scan_data.get('scan_mode', 'unknown'),
                    'filtered_vm_ips': scan_data.get('filtered_vm_ips', 0)
                }
        
        return agent_status

class NetworkMonitorHandler(http.server.SimpleHTTPRequestHandler):
    aggregator = None
    
    def send_cors_headers(self):
        """Send comprehensive CORS headers."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin')
        self.send_header('Access-Control-Max-Age', '86400')  # 24 hours
        self.send_header('Vary', 'Origin')
    
    def do_OPTIONS(self):
        """Handle OPTIONS request with proper CORS preflight response."""
        self.send_response(200)
        self.send_cors_headers()
        self.send_header('Content-Length', '0')
        self.end_headers()
    
    def do_GET(self):
        """Handle GET request."""
        if self.path == '/api/network':
            try:
                data = self.aggregator.scan_network()
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
            except Exception as e:
                logging.error(f"Error handling GET request: {e}")
                self.send_error(500, "Internal Server Error")
        
        elif self.path == '/api/agents/status':
            try:
                data = self.aggregator.get_agent_status()
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
            except Exception as e:
                logging.error(f"Error handling agent status request: {e}")
                self.send_error(500, "Internal Server Error")
        
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        """Handle POST request."""
        if self.path == '/api/network/start':
            try:
                self.aggregator.is_scanning = True
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'scanning_started'}).encode())
            except Exception as e:
                logging.error(f"Error handling start scan request: {e}")
                self.send_error(500, "Internal Server Error")
        
        elif self.path == '/api/network/stop':
            try:
                self.aggregator.is_scanning = False
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'scanning_stopped'}).encode())
            except Exception as e:
                logging.error(f"Error handling stop scan request: {e}")
                self.send_error(500, "Internal Server Error")
        
        elif self.path == '/api/network/remote_scan_report':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                scan_data = json.loads(post_data.decode('utf-8'))
                
                # Get the client IP address
                client_ip = self.client_address[0]
                
                # Process the remote scan data
                success = self.aggregator.receive_remote_scan(client_ip, scan_data)
                
                if success:
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_cors_headers()
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'received', 'agent_id': client_ip}).encode())
                else:
                    self.send_error(400, "Invalid scan data")
                    
            except Exception as e:
                logging.error(f"Error handling remote scan report: {e}")
                self.send_error(500, "Internal Server Error")
        
        elif self.path == '/api/insights':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                request_data = json.loads(post_data.decode('utf-8'))
                
                # Extract network data and API key from request
                network_data = request_data.get('networkData', {})
                api_key = request_data.get('apiKey', '')
                
                logging.info(f"Generating AI insights for network data with {len(network_data.get('agents', {}))} agents")
                
                # Generate AI insights
                insights = generate_ai_insights(network_data, api_key)
                
                response_data = {
                    'insights': insights,
                    'timestamp': time.time(),
                    'agent_count': len(network_data.get('agents', {})),
                    'api_key_provided': bool(api_key and len(api_key.strip()) > 0)
                }
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(response_data).encode())
                
                logging.info(f"Successfully generated {len(insights)} AI insights")
                
            except json.JSONDecodeError as e:
                logging.error(f"Invalid JSON in insights request: {e}")
                self.send_error(400, "Invalid JSON data")
            except Exception as e:
                logging.error(f"Error handling insights request: {e}")
                self.send_error(500, "Internal Server Error")
        
        else:
            self.send_error(404, "Not Found")

def run_server(port: int = 5000):
    """Run the network monitoring server."""
    try:
        # Get port from environment variable if set
        port = int(os.environ.get('BACKEND_PORT', port))
        
        # Get scan mode from environment variable
        scan_mode = os.environ.get('SCAN_MODE', 'internet-facing')
        
        # Initialize the aggregator with scan mode
        NetworkMonitorHandler.aggregator = NetworkAggregator(scan_mode)
        
        with socketserver.TCPServer(("", port), NetworkMonitorHandler) as httpd:
            logging.info(f"Network Aggregator Server running on port {port}")
            logging.info(f"Local IP: {NetworkMonitorHandler.aggregator.local_ip}")
            logging.info(f"Scan mode: {scan_mode}")
            logging.info("Endpoints available:")
            logging.info("  GET  /api/network - Get aggregated network data")
            logging.info("  GET  /api/agents/status - Get agent status")
            logging.info("  POST /api/network/start - Start local scanning")
            logging.info("  POST /api/network/stop - Stop local scanning")
            logging.info("  POST /api/network/remote_scan_report - Receive remote scan data")
            logging.info("  POST /api/insights - Generate AI security insights")
            httpd.serve_forever()
    except Exception as e:
        logging.error(f"Server error: {e}")
        raise

if __name__ == "__main__":
    run_server()