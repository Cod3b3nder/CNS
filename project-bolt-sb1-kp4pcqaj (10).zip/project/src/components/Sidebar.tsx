import React from 'react';
import { X, LayoutDashboard, Network, Users, Settings, Menu, Activity, Shield, Server } from 'lucide-react';

interface SystemMetrics {
  cpu_usage: number;
  memory_total: number;
  memory_used: number;
  memory_free: number;
  disk_total?: number;
  disk_used?: number;
  disk_free?: number;
}

interface AgentScanData {
  agent_id: string;
  agent_type: 'local' | 'remote';
  devices: any[];
  metrics: SystemMetrics;
  timestamp: number;
  scanning?: boolean;
  network_range?: string;
  received_at?: number;
  agent_info?: {
    ip: string;
    hostname: string;
    platform: string;
    version: string;
  };
}

interface AggregatedNetworkData {
  agents: Record<string, AgentScanData>;
  agent_count: number;
  local_agent: string;
  timestamp: number;
}

interface AgentStatus {
  type: 'local' | 'remote';
  last_seen: number;
  status: 'active' | 'stale';
  device_count: number;
  network_range: string;
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeView: 'dashboard' | 'network' | 'agents' | 'settings';
  onViewChange: (view: 'dashboard' | 'network' | 'agents' | 'settings') => void;
  networkData: AggregatedNetworkData | null;
  agentStatus: Record<string, AgentStatus>;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  activeView,
  onViewChange,
  networkData,
  agentStatus
}) => {
  const totalDevices = networkData ? Object.values(networkData.agents).reduce((sum, agent) => sum + agent.devices.length, 0) : 0;
  const activeAgents = Object.values(agentStatus).filter(agent => agent.status === 'active').length;

  const menuItems = [
    {
      id: 'dashboard' as const,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'System overview'
    },
    {
      id: 'network' as const,
      label: 'Network Map',
      icon: Network,
      description: 'Visual network topology'
    },
    {
      id: 'agents' as const,
      label: 'Agent Management',
      icon: Users,
      description: 'Remote scanning agents'
    },
    {
      id: 'settings' as const,
      label: 'Settings',
      icon: Settings,
      description: 'System configuration'
    }
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-80 bg-[#0a0a0a] border-r border-[#00ff00] transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:inset-0
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-[#00ff00]">
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8 text-[#00ff00]" />
              <div>
                <h1 className="text-lg neon-text">OOX LAB CNS</h1>
                <p className="text-xs opacity-60">Network Security Scanner</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#222222] rounded lg:hidden"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Stats Overview */}
          <div className="p-6 border-b border-[#222222]">
            <div className="grid grid-cols-2 gap-4">
              <div className="cyber-panel p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <Network className="h-4 w-4 text-[#00f7ff]" />
                  <span className="text-xs opacity-60">Devices</span>
                </div>
                <div className="text-lg text-[#00ff00]">{totalDevices}</div>
              </div>
              <div className="cyber-panel p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <Server className="h-4 w-4 text-[#00f7ff]" />
                  <span className="text-xs opacity-60">Agents</span>
                </div>
                <div className="text-lg text-[#00ff00]">{activeAgents}</div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6">
            <div className="space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onViewChange(item.id);
                      onClose();
                    }}
                    className={`
                      w-full flex items-center space-x-3 p-3 rounded transition-colors text-left
                      ${isActive 
                        ? 'bg-[#00ff00]/20 border border-[#00ff00] text-[#00ff00]' 
                        : 'hover:bg-[#222222] text-[#00f7ff]'
                      }
                    `}
                  >
                    <Icon className="h-5 w-5" />
                    <div>
                      <div className="font-medium">{item.label}</div>
                      <div className="text-xs opacity-60">{item.description}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </nav>

          {/* System Status */}
          <div className="p-6 border-t border-[#222222]">
            <div className="cyber-panel p-3">
              <div className="flex items-center space-x-2 mb-2">
                <Activity className="h-4 w-4 text-[#00f7ff]" />
                <span className="text-sm">System Status</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="opacity-60">Network:</span>
                  <span className="text-[#00ff00]">Online</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-60">Scanner:</span>
                  <span className="text-[#00ff00]">Active</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-60">Security:</span>
                  <span className="text-[#00ff00]">Protected</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;