#!/usr/bin/env python3

import json
import logging
import nmap
import platform
import requests
import socket
import time
import threading
from typing import Dict, List, Any
import argparse
import sys

# Try to import psutil with fallback metrics
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    logging.warning("psutil not available. Using fallback system metrics.")
    PSUTIL_AVAILABLE = False

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('remote_scanner.log'),
        logging.StreamHandler()
    ]
)

# Device identification based on MAC address prefixes (OUI)
DEVICE_MANUFACTURERS = {
    # Apple devices
    '00:03:93': 'Apple',
    '00:05:02': 'Apple',
    '00:0A:27': 'Apple',
    '00:0A:95': 'Apple',
    '00:1B:63': 'Apple',
    '00:1E:52': 'Apple',
    '00:1F:5B': 'Apple',
    '00:1F:F3': 'Apple',
    '00:21:E9': 'Apple',
    '00:22:41': 'Apple',
    '00:23:12': 'Apple',
    '00:23:32': 'Apple',
    '00:24:36': 'Apple',
    '00:25:00': 'Apple',
    '00:26:08': 'Apple',
    '00:26:B0': 'Apple',
    '00:26:BB': 'Apple',
    '00:30:65': 'Apple',
    
    # Samsung devices
    '00:07:AB': 'Samsung',
    '00:12:47': 'Samsung',
    '00:15:99': 'Samsung',
    '00:17:C9': 'Samsung',
    '00:1C:43': 'Samsung',
    '00:21:19': 'Samsung',
    '00:23:39': 'Samsung',
    '00:24:54': 'Samsung',
    '00:26:37': 'Samsung',
    
    # Printers
    '00:00:AA': 'Xerox',
    '00:00:17': 'Epson',
    '00:01:E6': 'Hewlett-Packard',
    '00:02:B3': 'Intel',
    '00:04:EA': 'Hewlett-Packard',
    '00:08:C7': 'Hewlett-Packard',
    '00:0B:CD': 'Hewlett-Packard',
    '00:0F:61': 'Hewlett-Packard',
    '00:11:0A': 'Hewlett-Packard',
    '00:13:21': 'Hewlett-Packard',
    
    # Smart TVs
    '00:12:FB': 'Samsung Electronics',
    '08:00:28': 'Texas Instruments',
    '00:1A:11': 'Google',
    '00:1E:45': 'Sony',
    '00:26:75': 'Sony',
    
    # IoT and Smart Home
    '00:17:88': 'Philips Lighting',
    '00:24:E4': 'Withings',
    'D0:52:A8': 'Physical Web',
    '44:65:0D': 'Amazon',
    
    # Network equipment
    '00:06:25': 'Linksys',
    '00:18:F8': 'Cisco-Linksys',
    '00:14:BF': 'Cisco-Linksys',
    '00:1A:70': 'Cisco-Linksys',
    '00:21:29': 'Cisco-Linksys',
    '00:23:69': 'Cisco-Linksys',
    '00:25:9C': 'Cisco-Linksys',
}

# Device type identification based on ports and services
DEVICE_SIGNATURES = {
    'printer': {
        'ports': [631, 9100],
        'services': ['ipp', 'jetdirect', 'printer'],
    },
    'smart_tv': {
        'ports': [3000, 5000, 8008, 8009],
        'services': ['pnp', 'dlna', 'roku'],
    },
    'smartphone': {
        'ports': [62078, 5353],
        'services': ['lockdownd', 'mdns'],
    },
    'iot_device': {
        'ports': [1883, 8883],
        'services': ['mqtt', 'coap'],
    },
    'camera': {
        'ports': [554, 8000, 8080],
        'services': ['rtsp', 'hikvision', 'onvif'],
    },
    'game_console': {
        'ports': [3074, 3075, 3076],
        'services': ['xbox', 'playstation'],
    },
}

class RemoteScannerAgent:
    def __init__(self, main_server_url: str, scan_interval: int = 60):
        self.main_server_url = main_server_url.rstrip('/')
        self.scan_interval = scan_interval
        self.nm = nmap.PortScanner()
        self.is_running = False
        self.local_ip = self.get_local_ip()
        self.rate_limit = 50  # Limit for remote agents
        
        logging.info(f"Remote Scanner Agent initialized")
        logging.info(f"Main server: {self.main_server_url}")
        logging.info(f"Local IP: {self.local_ip}")
        logging.info(f"Scan interval: {self.scan_interval} seconds")

    def get_local_ip(self) -> str:
        """Get the local machine's IP address."""
        try:
            # Connect to a remote address to determine local IP
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except Exception:
            return "127.0.0.1"

    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system metrics with fallback if psutil is not available."""
        try:
            if PSUTIL_AVAILABLE:
                cpu_usage = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                return {
                    'cpu_usage': cpu_usage,
                    'memory_total': memory.total,
                    'memory_used': memory.used,
                    'memory_free': memory.available,
                    'disk_total': disk.total,
                    'disk_used': disk.used,
                    'disk_free': disk.free
                }
            else:
                # Fallback metrics
                return {
                    'cpu_usage': 0,
                    'memory_total': 8 * 1024 * 1024 * 1024,  # 8GB placeholder
                    'memory_used': 4 * 1024 * 1024 * 1024,   # 4GB placeholder
                    'memory_free': 4 * 1024 * 1024 * 1024,   # 4GB placeholder
                    'disk_total': 500 * 1024 * 1024 * 1024,  # 500GB placeholder
                    'disk_used': 250 * 1024 * 1024 * 1024,   # 250GB placeholder
                    'disk_free': 250 * 1024 * 1024 * 1024    # 250GB placeholder
                }
        except Exception as e:
            logging.error(f"Error getting system metrics: {e}")
            return {
                'cpu_usage': 0,
                'memory_total': 0,
                'memory_used': 0,
                'memory_free': 0,
                'disk_total': 0,
                'disk_used': 0,
                'disk_free': 0
            }

    def identify_device_type(self, mac_address: str, ports: List[Dict], hostname: str) -> Dict[str, str]:
        """Identify device type based on MAC address, ports, and hostname."""
        mac_prefix = mac_address[:8].upper()
        manufacturer = DEVICE_MANUFACTURERS.get(mac_prefix, 'Unknown')
        
        # Initialize device info
        device_info = {
            'manufacturer': manufacturer,
            'type': 'unknown',
            'model': 'unknown'
        }
        
        # Check ports against device signatures
        port_numbers = [p['port'] for p in ports]
        services = [p.get('service', '').lower() for p in ports]
        
        for device_type, signature in DEVICE_SIGNATURES.items():
            if any(port in signature['ports'] for port in port_numbers) or \
               any(service in signature['services'] for service in services):
                device_info['type'] = device_type
                break
        
        # Additional identification based on hostname and manufacturer
        hostname_lower = hostname.lower()
        if 'printer' in hostname_lower or manufacturer in ['Xerox', 'Epson', 'Hewlett-Packard']:
            device_info['type'] = 'printer'
        elif 'tv' in hostname_lower or manufacturer in ['Samsung Electronics', 'Sony', 'LG']:
            device_info['type'] = 'smart_tv'
        elif 'phone' in hostname_lower or manufacturer in ['Apple', 'Samsung']:
            device_info['type'] = 'smartphone'
        elif 'camera' in hostname_lower:
            device_info['type'] = 'camera'
        elif manufacturer in ['Philips Lighting', 'Physical Web', 'Amazon']:
            device_info['type'] = 'iot_device'
        
        return device_info

    def get_network_range(self) -> str:
        """Get the local network range."""
        try:
            # Get the default network interface
            if platform.system() == "Windows":
                interface = next((i for i in psutil.net_if_addrs() if "Ethernet" in i or "Wi-Fi" in i), None)
            else:
                interface = next((i for i in psutil.net_if_addrs() if i != "lo"), None)
            
            if not interface:
                raise ValueError("No suitable network interface found")

            # Get the IP address and netmask
            addrs = psutil.net_if_addrs()[interface]
            ip_info = next((addr for addr in addrs if addr.family == socket.AF_INET), None)
            
            if not ip_info:
                raise ValueError("No IPv4 address found")

            # Calculate network range
            ip_parts = ip_info.address.split('.')
            return f"{'.'.join(ip_parts[:-1])}.0/24"
            
        except Exception as e:
            logging.error(f"Error getting network range: {e}")
            return "192.168.1.0/24"  # Fallback to common local network

    def perform_nmap_scan(self, target: str) -> Dict[str, Any]:
        """Perform detailed Nmap scan on a target."""
        try:
            # Perform OS and version detection
            self.nm.scan(target, arguments='-sS -sV -O --version-intensity 3')
            
            if target not in self.nm.all_hosts():
                return None

            host_info = self.nm[target]
            
            # Get MAC address if available
            mac_address = host_info.get('addresses', {}).get('mac', '')
            
            # Extract OS details
            os_info = {
                'name': 'Unknown',
                'accuracy': 0,
                'family': 'Unknown'
            }
            
            if 'osmatch' in host_info and host_info['osmatch']:
                best_match = host_info['osmatch'][0]
                os_info = {
                    'name': best_match['name'],
                    'accuracy': best_match['accuracy'],
                    'family': best_match['osclass'][0]['osfamily'] if best_match.get('osclass') else 'Unknown'
                }

            # Extract port and service information
            ports_info = []
            if 'tcp' in host_info:
                for port, data in host_info['tcp'].items():
                    ports_info.append({
                        'port': port,
                        'state': data['state'],
                        'service': data['name'],
                        'version': data.get('version', ''),
                        'product': data.get('product', '')
                    })

            # Identify device type
            device_info = self.identify_device_type(mac_address, ports_info, socket.getfqdn(target))

            # Determine device status based on open ports and services
            status = 'safe'
            suspicious_ports = {21, 22, 23, 3389}  # FTP, SSH, Telnet, RDP
            open_suspicious = any(p['port'] in suspicious_ports and p['state'] == 'open' for p in ports_info)
            
            if open_suspicious:
                status = 'warning'
            if len([p for p in ports_info if p['state'] == 'open']) > 5:
                status = 'compromised'

            return {
                'ip': target,
                'hostname': socket.getfqdn(target),
                'mac_address': mac_address,
                'manufacturer': device_info['manufacturer'],
                'device_type': device_info['type'],
                'model': device_info['model'],
                'os': os_info,
                'ports': ports_info,
                'status': status,
                'last_seen': time.time()
            }
            
        except Exception as e:
            logging.error(f"Error during Nmap scan of {target}: {e}")
            return None

    def scan_local_network(self) -> Dict[str, Any]:
        """Perform network scan of local environment."""
        try:
            devices = []
            network_range = self.get_network_range()
            
            logging.info(f"Starting network scan on {network_range}")
            
            # Perform initial fast ping scan
            self.nm.scan(hosts=network_range, arguments='-sn')
            hosts = self.nm.all_hosts()
            
            logging.info(f"Found {len(hosts)} hosts, scanning up to {self.rate_limit}")
            
            # Detailed scan of discovered hosts
            for host in hosts[:self.rate_limit]:
                try:
                    scan_result = self.perform_nmap_scan(host)
                    if scan_result:
                        devices.append(scan_result)
                        logging.info(f"Scanned device: {scan_result['hostname']} ({scan_result['ip']})")
                        
                except Exception as e:
                    logging.error(f"Error scanning host {host}: {e}")
                    continue
            
            return {
                'devices': devices,
                'metrics': self.get_system_metrics(),
                'timestamp': time.time(),
                'network_range': network_range,
                'agent_info': {
                    'ip': self.local_ip,
                    'hostname': socket.gethostname(),
                    'platform': platform.system(),
                    'version': platform.version()
                }
            }
            
        except Exception as e:
            logging.error(f"Error during network scan: {e}")
            return None

    def send_scan_data(self, scan_data: Dict[str, Any]) -> bool:
        """Send scan data to the main server."""
        try:
            url = f"{self.main_server_url}/api/network/remote_scan_report"
            headers = {
                'Content-Type': 'application/json',
                'User-Agent': f'RemoteScannerAgent/{self.local_ip}'
            }
            
            response = requests.post(
                url,
                json=scan_data,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                logging.info(f"Successfully sent scan data to main server. Agent ID: {result.get('agent_id')}")
                return True
            else:
                logging.error(f"Failed to send scan data: HTTP {response.status_code}")
                return False
                
        except requests.exceptions.RequestException as e:
            logging.error(f"Network error sending scan data: {e}")
            return False
        except Exception as e:
            logging.error(f"Error sending scan data: {e}")
            return False

    def run_scan_cycle(self):
        """Run a single scan cycle."""
        try:
            logging.info("Starting scan cycle...")
            scan_data = self.scan_local_network()
            
            if scan_data:
                logging.info(f"Scan completed. Found {len(scan_data['devices'])} devices")
                success = self.send_scan_data(scan_data)
                
                if success:
                    logging.info("Scan data sent successfully")
                else:
                    logging.error("Failed to send scan data")
            else:
                logging.error("Scan failed - no data collected")
                
        except Exception as e:
            logging.error(f"Error in scan cycle: {e}")

    def start(self):
        """Start the remote scanner agent."""
        self.is_running = True
        logging.info("Remote Scanner Agent started")
        
        try:
            while self.is_running:
                self.run_scan_cycle()
                
                # Wait for next scan interval
                for _ in range(self.scan_interval):
                    if not self.is_running:
                        break
                    time.sleep(1)
                    
        except KeyboardInterrupt:
            logging.info("Received interrupt signal")
        except Exception as e:
            logging.error(f"Error in main loop: {e}")
        finally:
            self.stop()

    def stop(self):
        """Stop the remote scanner agent."""
        self.is_running = False
        logging.info("Remote Scanner Agent stopped")

def main():
    parser = argparse.ArgumentParser(description='Remote Network Scanner Agent')
    parser.add_argument(
        '--server',
        required=True,
        help='Main server URL (e.g., http://192.168.1.100:5000)'
    )
    parser.add_argument(
        '--interval',
        type=int,
        default=60,
        help='Scan interval in seconds (default: 60)'
    )
    parser.add_argument(
        '--test',
        action='store_true',
        help='Run a single test scan and exit'
    )
    
    args = parser.parse_args()
    
    # Validate server URL
    if not args.server.startswith(('http://', 'https://')):
        print("Error: Server URL must start with http:// or https://")
        sys.exit(1)
    
    # Create and configure the agent
    agent = RemoteScannerAgent(args.server, args.interval)
    
    if args.test:
        logging.info("Running test scan...")
        agent.run_scan_cycle()
        logging.info("Test scan completed")
    else:
        try:
            agent.start()
        except KeyboardInterrupt:
            logging.info("Shutting down...")
            agent.stop()

if __name__ == "__main__":
    main()