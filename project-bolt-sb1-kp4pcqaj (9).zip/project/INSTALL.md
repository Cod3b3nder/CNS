# OOX LAB CNS - Installation Guide

A distributed network security scanner with real-time monitoring capabilities.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Detailed Installation](#detailed-installation)
- [Manual Setup](#manual-setup)
- [Remote Agent Setup](#remote-agent-setup)
- [Troubleshooting](#troubleshooting)
- [Configuration](#configuration)
- [API Endpoints](#api-endpoints)

## Prerequisites

### System Requirements

- **Operating System**: Windows 10+, macOS 10.15+, or Linux (Ubuntu 18.04+, CentOS 7+)
- **RAM**: Minimum 4GB, Recommended 8GB+
- **Storage**: 2GB free space
- **Network**: Internet connection for initial setup

### Required Software

#### 1. Python 3.8+
**Check if installed:**
```bash
python --version
# or
python3 --version
```

**Installation:**
- **Windows**: Download from [python.org](https://www.python.org/downloads/)
- **macOS**: `brew install python3` or download from python.org
- **Linux**: 
  ```bash
  # Ubuntu/Debian
  sudo apt update && sudo apt install python3 python3-pip
  
  # CentOS/RHEL
  sudo yum install python3 python3-pip
  ```

#### 2. Node.js 18.0+
**Check if installed:**
```bash
node --version
npm --version
```

**Installation:**
- **Windows/macOS**: Download from [nodejs.org](https://nodejs.org/)
- **Linux**:
  ```bash
  # Ubuntu/Debian
  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
  sudo apt-get install -y nodejs
  
  # CentOS/RHEL
  curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
  sudo yum install -y nodejs
  ```

#### 3. Nmap (Network Mapper)
**Check if installed:**
```bash
nmap --version
```

**Installation:**
- **Windows**: Download from [nmap.org](https://nmap.org/download.html)
- **macOS**: `brew install nmap`
- **Linux**:
  ```bash
  # Ubuntu/Debian
  sudo apt install nmap
  
  # CentOS/RHEL
  sudo yum install nmap
  ```

## Quick Start

### Option 1: Automated Setup (Recommended)

1. **Clone or download the project**
2. **Run the automated setup script:**
   ```bash
   python local_server.py
   ```

The script will:
- Check all dependencies
- Install Python packages automatically
- Start both frontend and backend servers
- Provide real-time status monitoring

### Option 2: Manual Setup

If the automated script doesn't work, follow the [Manual Setup](#manual-setup) section below.

## Detailed Installation

### Step 1: Project Setup

1. **Download the project files** to your desired directory
2. **Open a terminal/command prompt** in the project directory
3. **Verify the project structure:**
   ```
   oox-lab-cns/
   ├── local_server.py
   ├── server/
   │   ├── app.py
   │   ├── requirements.txt
   │   └── README.md
   ├── src/
   ├── package.json
   └── README.md
   ```

### Step 2: Install Dependencies

#### Python Dependencies
```bash
# Navigate to the project directory
cd oox-lab-cns

# Install Python dependencies
pip install -r server/requirements.txt
```

#### Node.js Dependencies
```bash
# Install frontend dependencies
npm install
```

### Step 3: Start the Application

#### Using the Automated Script (Recommended)
```bash
python local_server.py
```

#### Manual Startup
```bash
# Terminal 1: Start Backend Server
cd server
python app.py

# Terminal 2: Start Frontend Server
npm run dev
```

### Step 4: Access the Application

- **Frontend Interface**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **Network Scanner API**: http://localhost:5000/api/network

## Manual Setup

If the automated script fails, follow these steps:

### 1. Install Python Dependencies Manually

```bash
# Create a virtual environment (optional but recommended)
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install python-nmap psutil requests
```

### 2. Install Node.js Dependencies

```bash
npm install
```

### 3. Start Servers Manually

**Backend Server:**
```bash
cd server
python app.py
```

**Frontend Server (in a new terminal):**
```bash
npm run dev
```

## Remote Agent Setup

To set up remote scanning agents on other machines:

### 1. Copy Agent Script

Copy `remote_scanner_agent.py` to the target machine.

### 2. Install Dependencies on Remote Machine

```bash
pip install python-nmap psutil requests
```

### 3. Run Remote Agent

```bash
# Replace YOUR_SERVER_IP with the IP of your main server
sudo python remote_scanner_agent.py --server http://YOUR_SERVER_IP:5000

# Optional parameters:
# --interval 60    # Scan interval in seconds
# --test          # Run single test scan
```

**Note**: Remote agents require administrator/sudo privileges for network scanning.

## Troubleshooting

### Common Issues

#### 1. Port Already in Use
**Error**: `Port 5000/5173 is already in use`

**Solution**:
```bash
# Find and kill processes using the ports
# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# macOS/Linux:
lsof -ti:5000 | xargs kill -9
lsof -ti:5173 | xargs kill -9
```

#### 2. Permission Denied (Nmap)
**Error**: `Permission denied` when running network scans

**Solution**:
- **Windows**: Run Command Prompt as Administrator
- **macOS/Linux**: Use `sudo python local_server.py`

#### 3. Python Module Not Found
**Error**: `ModuleNotFoundError: No module named 'nmap'`

**Solution**:
```bash
pip install python-nmap psutil requests
```

#### 4. Node.js Dependencies Issues
**Error**: Various npm installation errors

**Solution**:
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### 5. Nmap Not Found
**Error**: `nmap: command not found`

**Solution**: Install Nmap using your system's package manager (see Prerequisites section)

### Debug Mode

For detailed logging, set the environment variable:
```bash
# Windows:
set DEBUG=1
python local_server.py

# macOS/Linux:
DEBUG=1 python local_server.py
```

### Log Files

Check these log files for detailed error information:
- `network_monitor.log` - Backend server logs
- `setup.log` - Installation logs
- `remote_scanner.log` - Remote agent logs

## Configuration

### Environment Variables

Create a `.env` file in the project root:
```env
# Backend server configuration
BACKEND_PORT=5000
FRONTEND_PORT=5173

# Network scanning configuration
SCAN_INTERVAL=30
RATE_LIMIT=100

# Security settings
API_KEY=your_api_key_here
```

### Server Configuration

Edit `server/app.py` to modify:
- Scan intervals
- Rate limiting
- Network ranges
- Security policies

## API Endpoints

### Network Scanner API

#### Get Network Data
```http
GET /api/network
```
Returns aggregated network scan data from all agents.

#### Start Scanning
```http
POST /api/network/start
```
Starts local network scanning.

#### Stop Scanning
```http
POST /api/network/stop
```
Stops local network scanning.

#### Agent Status
```http
GET /api/agents/status
```
Returns status of all registered scanning agents.

#### Remote Scan Report
```http
POST /api/network/remote_scan_report
```
Endpoint for remote agents to submit scan data.

### Example API Response

```json
{
  "agents": {
    "192.168.1.100": {
      "agent_id": "192.168.1.100",
      "agent_type": "local",
      "devices": [
        {
          "ip": "192.168.1.1",
          "hostname": "router.local",
          "os": {
            "name": "Linux 4.15",
            "accuracy": 95,
            "family": "Linux"
          },
          "ports": [
            {
              "port": 80,
              "state": "open",
              "service": "http",
              "version": "2.4.29",
              "product": "Apache httpd"
            }
          ],
          "status": "safe",
          "last_seen": 1647123456.789
        }
      ],
      "metrics": {
        "cpu_usage": 45.2,
        "memory_total": 16000000000,
        "memory_used": 8000000000,
        "memory_free": 8000000000
      },
      "timestamp": 1647123456.789
    }
  },
  "agent_count": 1,
  "local_agent": "192.168.1.100",
  "timestamp": 1647123456.789
}
```

## Security Considerations

### Network Scanning
- Network scanning requires elevated privileges
- Scanning may trigger security systems
- Use responsibly and only on networks you own or have permission to scan

### Remote Agents
- Remote agents communicate over HTTP (consider HTTPS for production)
- Agents automatically register with the main server
- Monitor agent activity through the web interface

### Data Privacy
- All scan data is stored locally
- No data is transmitted to external services
- Network topology and device information remains on your network

## Support

For issues and questions:
1. Check the [Troubleshooting](#troubleshooting) section
2. Review log files for error details
3. Ensure all prerequisites are properly installed
4. Verify network connectivity and permissions

## License

This project is for educational and authorized network monitoring purposes only. Use responsibly and in compliance with local laws and regulations.