import React from 'react';
import { Server, Monitor, AlertCircle, CheckCircle, Clock, Network, Users } from 'lucide-react';
import { formatDistanceToNow, formatBytes } from '../utils/format';

interface SystemMetrics {
  cpu_usage: number;
  memory_total: number;
  memory_used: number;
  memory_free: number;
  disk_total?: number;
  disk_used?: number;
  disk_free?: number;
}

interface AgentScanData {
  agent_id: string;
  agent_type: 'local' | 'remote';
  devices: any[];
  metrics: SystemMetrics;
  timestamp: number;
  scanning?: boolean;
  network_range?: string;
  received_at?: number;
  agent_info?: {
    ip: string;
    hostname: string;
    platform: string;
    version: string;
  };
}

interface AggregatedNetworkData {
  agents: Record<string, AgentScanData>;
  agent_count: number;
  local_agent: string;
  timestamp: number;
}

interface AgentStatus {
  type: 'local' | 'remote';
  last_seen: number;
  status: 'active' | 'stale';
  device_count: number;
  network_range: string;
}

interface AgentManagementPanelProps {
  networkData: AggregatedNetworkData | null;
  agentStatus: Record<string, AgentStatus>;
  backendUrl: string;
}

export function AgentManagementPanel({ networkData, agentStatus, backendUrl }: AgentManagementPanelProps) {
  if (!networkData) {
    return (
      <div className="cyber-panel p-4 h-[400px] flex items-center justify-center">
        <span className="text-[#00f7ff]">Loading agent information...</span>
      </div>
    );
  }

  const agents = Object.entries(networkData.agents);

  return (
    <div className="cyber-panel p-4 h-[400px] overflow-auto">
      <h3 className="text-sm mb-4 neon-text">AGENT MANAGEMENT</h3>
      
      <div className="space-y-4">
        {/* Summary */}
        <div className="cyber-panel p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Users className="h-4 w-4 text-[#00f7ff]" />
            <span className="text-sm">Network Overview</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="opacity-60">Total Agents:</span>
              <span className="ml-2 text-[#00ff00]">{networkData.agent_count}</span>
            </div>
            <div>
              <span className="opacity-60">Total Devices:</span>
              <span className="ml-2 text-[#00ff00]">
                {Object.values(networkData.agents).reduce((sum, agent) => sum + agent.devices.length, 0)}
              </span>
            </div>
            <div>
              <span className="opacity-60">Local Agent:</span>
              <span className="ml-2 text-[#00f7ff]">{networkData.local_agent}</span>
            </div>
            <div>
              <span className="opacity-60">Backend:</span>
              <span className="ml-2 text-[#00f7ff]">{new URL(backendUrl).hostname}</span>
            </div>
          </div>
        </div>

        {/* Agent List */}
        {agents.map(([agentId, agent]) => {
          const status = agentStatus[agentId];
          const isLocal = agent.agent_type === 'local';
          const isActive = status?.status === 'active';
          
          return (
            <div key={agentId} className="cyber-panel p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {isLocal ? (
                    <Monitor className="h-4 w-4 text-[#00f7ff]" />
                  ) : (
                    <Server className="h-4 w-4 text-[#00ff00]" />
                  )}
                  <span className="font-medium">
                    {agent.agent_info?.hostname || agentId}
                  </span>
                  <span className="text-xs opacity-60">
                    ({agent.agent_type})
                  </span>
                </div>
                <div className="flex items-center space-x-1">
                  {isActive ? (
                    <CheckCircle className="h-4 w-4 text-[#00ff00]" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-[#ff0033]" />
                  )}
                  <span className={`text-xs ${isActive ? 'text-[#00ff00]' : 'text-[#ff0033]'}`}>
                    {isActive ? 'Active' : 'Stale'}
                  </span>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="opacity-60">IP Address:</span>
                    <div className="text-[#00f7ff]">{agentId}</div>
                  </div>
                  <div>
                    <span className="opacity-60">Platform:</span>
                    <div className="text-[#00f7ff]">
                      {agent.agent_info?.platform || 'Unknown'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="opacity-60">Devices Found:</span>
                    <div className="text-[#00ff00]">{agent.devices.length}</div>
                  </div>
                  <div>
                    <span className="opacity-60">Network Range:</span>
                    <div className="text-[#00ff00]">{agent.network_range || 'Unknown'}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="opacity-60">Last Scan:</span>
                    <div className="text-[#00f7ff]">
                      {formatDistanceToNow(agent.timestamp)}
                    </div>
                  </div>
                  {agent.received_at && (
                    <div>
                      <span className="opacity-60">Received:</span>
                      <div className="text-[#00f7ff]">
                        {formatDistanceToNow(agent.received_at)}
                      </div>
                    </div>
                  )}
                </div>

                {/* System Metrics */}
                <div className="mt-2 pt-2 border-t border-[#222222]">
                  <div className="flex items-center space-x-2 mb-1">
                    <Monitor className="h-3 w-3" />
                    <span className="opacity-60">System Metrics</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="opacity-60">CPU:</span>
                      <span className={`ml-2 ${agent.metrics.cpu_usage > 80 ? 'text-[#ff0033]' : 'text-[#00ff00]'}`}>
                        {agent.metrics.cpu_usage.toFixed(1)}%
                      </span>
                    </div>
                    <div>
                      <span className="opacity-60">Memory:</span>
                      <span className="ml-2 text-[#00ff00]">
                        {formatBytes(agent.metrics.memory_used)} / {formatBytes(agent.metrics.memory_total)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Setup Instructions */}
        <div className="cyber-panel p-3">
          <div className="flex items-center space-x-2 mb-2">
            <Network className="h-4 w-4 text-[#00f7ff]" />
            <span className="text-sm">Add Remote Agent</span>
          </div>
          <div className="text-xs space-y-2">
            <p className="opacity-80">
              To add a remote scanning agent, copy <code className="bg-[#222222] px-1 rounded">remote_scanner_agent.py</code> to the target machine and run:
            </p>
            <code className="block bg-[#222222] p-2 rounded text-[#00ff00]">
              sudo python remote_scanner_agent.py --server {backendUrl}
            </code>
            <p className="opacity-60">
              The agent will automatically register and begin sending scan data to this server.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}