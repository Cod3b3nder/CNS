import React, { useEffect, useRef, useState } from 'react';
import { formatDistanceToNow } from '../utils/format';

interface Device {
  ip: string;
  hostname: string;
  status: string;
  last_seen: number;
  ports: Array<{
    port: number;
    state: string;
    service: string;
  }>;
}

interface LogEntry {
  timestamp: number;
  type: 'info' | 'warning' | 'error';
  message: string;
}

interface LogPanelProps {
  title: string;
  devices: Device[] | undefined;
}

export function LogPanel({ title, devices }: LogPanelProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!devices) return;

    const newLogs: LogEntry[] = [];
    const now = Date.now();

    devices.forEach(device => {
      // Log device status
      if (device.status === 'compromised') {
        newLogs.push({
          timestamp: now,
          type: 'error',
          message: `Security breach detected on ${device.hostname} (${device.ip})`
        });
      } else if (device.status === 'warning') {
        newLogs.push({
          timestamp: now,
          type: 'warning',
          message: `Suspicious activity on ${device.hostname} (${device.ip})`
        });
      }

      // Log open ports
      const openPorts = device.ports.filter(port => port.state === 'open');
      if (openPorts.length > 0) {
        newLogs.push({
          timestamp: now,
          type: 'info',
          message: `Device ${device.hostname} (${device.ip}) has ${openPorts.length} open ports: ${openPorts.map(p => `${p.port}/${p.service}`).join(', ')}`
        });
      }

      // Log last seen
      newLogs.push({
        timestamp: now,
        type: 'info',
        message: `Device ${device.hostname} last seen ${formatDistanceToNow(device.last_seen)}`
      });
    });

    setLogs(prev => [...newLogs, ...prev].slice(0, 100)); // Keep last 100 logs
  }, [devices]);

  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = 0;
    }
  }, [logs]);

  if (!devices) {
    return (
      <div className="h-full flex items-center justify-center">
        <span className="text-[#00f7ff] animate-pulse">Collecting system logs...</span>
      </div>
    );
  }

  return (
    <div className="h-full">
      <h3 className="text-sm mb-4 neon-text">{title}</h3>
      <div
        ref={logContainerRef}
        className="font-mono text-xs space-y-2 h-[calc(100%-2rem)] overflow-y-auto scrollbar-thin scrollbar-thumb-[#00f7ff] scrollbar-track-[#222222] pr-2"
      >
        {logs.map((log, index) => (
          <div
            key={index}
            className={`
              ${log.type === 'error' ? 'text-[#ff0033]' : ''}
              ${log.type === 'warning' ? 'text-[#f59e0b]' : ''}
              ${log.type === 'info' ? 'text-[#00f7ff]' : ''}
              cyber-panel p-2 widget-enter
            `}
          >
            <span className="opacity-60">[{formatDistanceToNow(log.timestamp)}]</span> {log.message}
          </div>
        ))}
      </div>
    </div>
  );
}