import React from 'react';
import { Network, Menu, Play, Square, Settings, Activity, Server, Monitor } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  fetchStatus: 'idle' | 'loading' | 'success' | 'error';
  backendUrl: string;
  agentCount: number;
  isScanning: boolean;
  onStartScanning: () => void;
  onStopScanning: () => void;
  onSettingsClick: () => void;
}

export function Header({ 
  onMenuClick, 
  fetchStatus, 
  backendUrl, 
  agentCount, 
  isScanning, 
  onStartScanning, 
  onStopScanning, 
  onSettingsClick 
}: HeaderProps) {
  const getStatusColor = () => {
    switch (fetchStatus) {
      case 'loading': return 'text-[#f59e0b]';
      case 'success': return 'text-[#00ff00]';
      case 'error': return 'text-[#ff0033]';
      default: return 'text-gray-400';
    }
  };

  const getStatusText = () => {
    switch (fetchStatus) {
      case 'loading': return 'Scanning...';
      case 'success': return 'Online';
      case 'error': return 'Offline';
      default: return 'Idle';
    }
  };

  return (
    <header className="bg-[#111111] border-b border-[#00ff00] p-4">
      <div className="flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center space-x-4">
          <button
            onClick={onMenuClick}
            className="p-2 hover:bg-[#222222] rounded lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
          
          <div className="flex items-center space-x-3">
            <Network className="h-6 w-6 text-[#00ff00]" />
            <div>
              <h1 className="text-lg neon-text">OOX LAB CNS</h1>
              <p className="text-xs opacity-60">Network Security Scanner</p>
            </div>
          </div>
        </div>

        {/* Center Section - Status */}
        <div className="hidden md:flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <Activity className={`h-4 w-4 ${getStatusColor()}`} />
            <span className={`text-sm ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Server className="h-4 w-4 text-[#00f7ff]" />
            <span className="text-sm text-[#00f7ff]">
              {agentCount} Agent{agentCount !== 1 ? 's' : ''}
            </span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Monitor className="h-4 w-4 text-[#00f7ff]" />
            <span className="text-sm text-[#00f7ff]">
              {new URL(backendUrl).hostname}
            </span>
          </div>
        </div>

        {/* Right Section - Controls */}
        <div className="flex items-center space-x-2">
          {isScanning ? (
            <button
              onClick={onStopScanning}
              className="flex items-center space-x-2 px-3 py-2 bg-[#ff0033] text-white rounded hover:bg-[#ff0033]/80 transition-colors"
            >
              <Square className="h-4 w-4" />
              <span className="hidden sm:inline">Stop Scan</span>
            </button>
          ) : (
            <button
              onClick={onStartScanning}
              className="flex items-center space-x-2 px-3 py-2 bg-[#00ff00] text-black rounded hover:bg-[#00ff00]/80 transition-colors"
            >
              <Play className="h-4 w-4" />
              <span className="hidden sm:inline">Start Scan</span>
            </button>
          )}
          
          <button
            onClick={onSettingsClick}
            className="p-2 hover:bg-[#222222] rounded transition-colors"
          >
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
}