import React, { useState } from 'react';
import { Network } from 'lucide-react';
import { LoginForm } from './LoginForm';
import { SignUpForm } from './SignUpForm';

export function AuthPage() {
  const [isSignUp, setIsSignUp] = useState(false);

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 grid-bg">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <Network className="h-8 w-8 text-[#00ff00]" />
            <span className="text-2xl neon-text">OOX LAB CNS</span>
          </div>
          <p className="text-sm opacity-60">
            Distributed Network Security Scanner
          </p>
        </div>

        {/* Auth Form */}
        {isSignUp ? (
          <SignUpForm onToggleMode={() => setIsSignUp(false)} />
        ) : (
          <LoginForm onToggleMode={() => setIsSignUp(true)} />
        )}

        {/* Footer */}
        <div className="text-center mt-8 text-xs opacity-40">
          <p>Secure • Encrypted • Monitored</p>
        </div>
      </div>
    </div>
  );
}