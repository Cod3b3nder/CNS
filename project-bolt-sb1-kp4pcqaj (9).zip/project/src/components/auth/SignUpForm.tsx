import React, { useState } from 'react';
import { Eye, EyeOff, UserPlus, Loader2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface SignUpFormProps {
  onToggleMode: () => void;
}

export function SignUpForm({ onToggleMode }: SignUpFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const { signUp } = useAuth();

  const validateForm = () => {
    const trimmedEmail = email.trim();
    const trimmedPassword = password.trim();
    const trimmedConfirmPassword = confirmPassword.trim();
    const trimmedUsername = username.trim();
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setError('Please enter a valid email address');
      return false;
    }
    
    // Password validation
    if (trimmedPassword.length < 6) {
      setError('Password must be at least 6 characters long');
      return false;
    }
    
    if (trimmedPassword !== trimmedConfirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    
    // Username validation
    if (trimmedUsername.length < 3) {
      setError('Username must be at least 3 characters long');
      return false;
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(trimmedUsername)) {
      setError('Username can only contain letters, numbers, and underscores');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!validateForm()) {
      setIsLoading(false);
      return;
    }

    try {
      // Trim inputs to remove any leading/trailing whitespace
      const { error } = await signUp(email.trim(), password.trim(), username.trim());
      
      if (error) {
        setError(error.message);
      } else {
        setSuccess(true);
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <div className="cyber-panel p-8 w-full max-w-md text-center">
        <div className="mb-6">
          <div className="w-16 h-16 bg-[#00ff00]/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserPlus className="h-8 w-8 text-[#00ff00]" />
          </div>
          <h1 className="text-2xl neon-text mb-2">ACCOUNT CREATED</h1>
          <p className="text-sm opacity-60">
            Your account has been successfully created. You can now sign in to access the system.
          </p>
        </div>
        
        <button
          onClick={onToggleMode}
          className="w-full bg-[#00ff00] text-black p-3 rounded font-medium hover:bg-[#00ff00]/80 transition-colors"
        >
          Continue to Sign In
        </button>
      </div>
    );
  }

  return (
    <div className="cyber-panel p-8 w-full max-w-md">
      <div className="text-center mb-8">
        <h1 className="text-2xl neon-text mb-2">CREATE ACCOUNT</h1>
        <p className="text-sm opacity-60">Join the network monitoring system</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="username" className="block text-sm mb-2">
            Username
          </label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-[#111111] border border-[#00ff00] p-3 rounded text-[#00ff00] placeholder-[#00ff00]/50 focus:outline-none focus:border-[#00f7ff] transition-colors"
            placeholder="Choose a username"
            required
            disabled={isLoading}
            minLength={3}
            pattern="[a-zA-Z0-9_]+"
            title="Username can only contain letters, numbers, and underscores"
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm mb-2">
            Email Address
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#111111] border border-[#00ff00] p-3 rounded text-[#00ff00] placeholder-[#00ff00]/50 focus:outline-none focus:border-[#00f7ff] transition-colors"
            placeholder="user@example.com"
            required
            disabled={isLoading}
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm mb-2">
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#111111] border border-[#00ff00] p-3 rounded text-[#00ff00] placeholder-[#00ff00]/50 focus:outline-none focus:border-[#00f7ff] transition-colors pr-12"
              placeholder="Create a password"
              required
              disabled={isLoading}
              minLength={6}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#00ff00]/60 hover:text-[#00ff00] transition-colors"
              disabled={isLoading}
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <div>
          <label htmlFor="confirmPassword" className="block text-sm mb-2">
            Confirm Password
          </label>
          <div className="relative">
            <input
              id="confirmPassword"
              type={showConfirmPassword ? 'text' : 'password'}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full bg-[#111111] border border-[#00ff00] p-3 rounded text-[#00ff00] placeholder-[#00ff00]/50 focus:outline-none focus:border-[#00f7ff] transition-colors pr-12"
              placeholder="Confirm your password"
              required
              disabled={isLoading}
              minLength={6}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#00ff00]/60 hover:text-[#00ff00] transition-colors"
              disabled={isLoading}
            >
              {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {error && (
          <div className="cyber-panel p-3 border-[#ff0033] text-[#ff0033] text-sm">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#00ff00] text-black p-3 rounded font-medium hover:bg-[#00ff00]/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Creating Account...</span>
            </>
          ) : (
            <>
              <UserPlus className="h-5 w-5" />
              <span>Create Account</span>
            </>
          )}
        </button>
      </form>

      <div className="mt-6 text-center">
        <p className="text-sm opacity-60">
          Already have an account?{' '}
          <button
            onClick={onToggleMode}
            className="text-[#00f7ff] hover:underline"
            disabled={isLoading}
          >
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
}