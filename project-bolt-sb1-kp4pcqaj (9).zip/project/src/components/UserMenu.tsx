import React, { useState } from 'react';
import { User, LogOut, Settings, ChevronDown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function UserMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, profile, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    setIsOpen(false);
  };

  if (!user || !profile) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 px-3 py-2 rounded bg-[#00ff00]/20 hover:bg-[#00ff00]/30 transition-colors"
      >
        <div className="w-8 h-8 bg-[#00ff00]/20 rounded-full flex items-center justify-center">
          <User className="h-4 w-4" />
        </div>
        <span className="text-sm">{profile.username}</span>
        <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-10"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-48 cyber-panel p-2 z-20">
            <div className="space-y-1">
              <div className="px-3 py-2 text-xs opacity-60 border-b border-[#222222]">
                <div>{profile.email}</div>
                <div>ID: {user.id.slice(0, 8)}...</div>
              </div>
              
              <button className="w-full flex items-center space-x-2 px-3 py-2 text-sm hover:bg-[#222222] rounded transition-colors">
                <Settings className="h-4 w-4" />
                <span>Settings</span>
              </button>
              
              <button
                onClick={handleSignOut}
                className="w-full flex items-center space-x-2 px-3 py-2 text-sm hover:bg-[#ff0033]/20 text-[#ff0033] rounded transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}