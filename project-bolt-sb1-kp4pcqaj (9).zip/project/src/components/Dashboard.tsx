import React from 'react';
import { StatusPanel } from './StatusPanel';
import { ThreatPanel } from './ThreatPanel';
import { LogPanel } from './LogPanel';
import { CustomInsightsPanel } from './CustomInsightsPanel';
import { AgentManagementPanel } from './AgentManagementPanel';
import { NetworkMap } from './NetworkMap';
import { Shield, Activity, Network, Users, Brain, AlertTriangle } from 'lucide-react';

interface SystemMetrics {
  cpu_usage: number;
  memory_total: number;
  memory_used: number;
  memory_free: number;
  disk_total?: number;
  disk_used?: number;
  disk_free?: number;
}

interface Device {
  ip: string;
  hostname: string;
  status: string;
  ports: Array<{
    port: number;
    state: string;
    service: string;
  }>;
}

interface AgentScanData {
  agent_id: string;
  agent_type: 'local' | 'remote';
  devices: Device[];
  metrics: SystemMetrics;
  timestamp: number;
  scanning?: boolean;
  network_range?: string;
  received_at?: number;
  agent_info?: {
    ip: string;
    hostname: string;
    platform: string;
    version: string;
  };
}

interface AggregatedNetworkData {
  agents: Record<string, AgentScanData>;
  agent_count: number;
  local_agent: string;
  timestamp: number;
}

interface AgentStatus {
  type: 'local' | 'remote';
  last_seen: number;
  status: 'active' | 'stale';
  device_count: number;
  network_range: string;
}

interface Insight {
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  recommendation?: string;
}

interface DashboardProps {
  networkData: AggregatedNetworkData | null;
  agentStatus: Record<string, AgentStatus>;
  metrics: SystemMetrics | undefined;
  devices: Device[];
  insights: Insight[] | null;
  isLoadingInsights: boolean;
  insightsError: string | null;
}

export const Dashboard: React.FC<DashboardProps> = ({
  networkData,
  agentStatus,
  metrics,
  devices,
  insights,
  isLoadingInsights,
  insightsError
}) => {
  const totalDevices = devices.length;
  const compromisedDevices = devices.filter(d => d.status === 'compromised').length;
  const warningDevices = devices.filter(d => d.status === 'warning').length;
  const safeDevices = devices.filter(d => d.status === 'safe').length;
  const activeAgents = Object.values(agentStatus).filter(agent => agent.status === 'active').length;

  // Calculate threat level
  const threatLevel = totalDevices > 0 
    ? ((compromisedDevices * 2 + warningDevices) / (totalDevices * 2)) * 100 
    : 0;

  const getThreatStatus = () => {
    if (threatLevel > 50) return { status: 'CRITICAL', color: '#ff0033' };
    if (threatLevel > 20) return { status: 'WARNING', color: '#f59e0b' };
    return { status: 'SECURE', color: '#00ff00' };
  };

  const threatStatus = getThreatStatus();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl neon-text mb-2">Network Security Dashboard</h1>
          <p className="text-sm opacity-60">Real-time network monitoring and threat analysis</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="cyber-panel p-3">
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-[#00f7ff]" />
              <span className="text-sm">System Status: </span>
              <span className="text-[#00ff00]">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="cyber-panel p-4">
          <div className="flex items-center space-x-3">
            <Network className="h-8 w-8 text-[#00f7ff]" />
            <div>
              <div className="text-2xl text-[#00ff00]">{totalDevices}</div>
              <div className="text-sm opacity-60">Total Devices</div>
            </div>
          </div>
        </div>

        <div className="cyber-panel p-4">
          <div className="flex items-center space-x-3">
            <Users className="h-8 w-8 text-[#00f7ff]" />
            <div>
              <div className="text-2xl text-[#00ff00]">{activeAgents}</div>
              <div className="text-sm opacity-60">Active Agents</div>
            </div>
          </div>
        </div>

        <div className="cyber-panel p-4">
          <div className="flex items-center space-x-3">
            <Shield className="h-8 w-8" style={{ color: threatStatus.color }} />
            <div>
              <div className="text-2xl" style={{ color: threatStatus.color }}>
                {threatStatus.status}
              </div>
              <div className="text-sm opacity-60">Threat Level</div>
            </div>
          </div>
        </div>

        <div className="cyber-panel p-4">
          <div className="flex items-center space-x-3">
            <Brain className="h-8 w-8 text-[#00f7ff]" />
            <div>
              <div className="text-2xl text-[#00ff00]">
                {insights ? insights.length : '0'}
              </div>
              <div className="text-sm opacity-60">AI Insights</div>
            </div>
          </div>
        </div>
      </div>

      {/* Device Status Breakdown */}
      <div className="cyber-panel p-4">
        <h3 className="text-lg mb-4 neon-text">Device Security Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-3xl text-[#00ff00] mb-2">{safeDevices}</div>
            <div className="text-sm opacity-60">Safe Devices</div>
            <div className="w-full bg-[#222222] rounded-full h-2 mt-2">
              <div 
                className="bg-[#00ff00] h-2 rounded-full" 
                style={{ width: `${totalDevices > 0 ? (safeDevices / totalDevices) * 100 : 0}%` }}
              />
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl text-[#f59e0b] mb-2">{warningDevices}</div>
            <div className="text-sm opacity-60">Warning Devices</div>
            <div className="w-full bg-[#222222] rounded-full h-2 mt-2">
              <div 
                className="bg-[#f59e0b] h-2 rounded-full" 
                style={{ width: `${totalDevices > 0 ? (warningDevices / totalDevices) * 100 : 0}%` }}
              />
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl text-[#ff0033] mb-2">{compromisedDevices}</div>
            <div className="text-sm opacity-60">Compromised Devices</div>
            <div className="w-full bg-[#222222] rounded-full h-2 mt-2">
              <div 
                className="bg-[#ff0033] h-2 rounded-full" 
                style={{ width: `${totalDevices > 0 ? (compromisedDevices / totalDevices) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="space-y-6">
          <StatusPanel metrics={metrics} />
          <ThreatPanel devices={devices} />
        </div>

        {/* Center Column */}
        <div className="space-y-6">
          <div className="cyber-panel p-4 h-[400px]">
            <h3 className="text-sm mb-4 neon-text">NETWORK TOPOLOGY</h3>
            <div className="h-[350px]">
              <NetworkMap networkData={networkData} />
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <CustomInsightsPanel 
            insights={insights} 
            isLoading={isLoadingInsights} 
            error={insightsError} 
          />
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="cyber-panel p-4 h-[400px]">
          <LogPanel title="SYSTEM LOGS" devices={devices} />
        </div>
        
        <AgentManagementPanel
          networkData={networkData}
          agentStatus={agentStatus}
          backendUrl="http://localhost:5000"
        />
      </div>

      {/* Critical Alerts Banner */}
      {compromisedDevices > 0 && (
        <div className="cyber-panel p-4 border-[#ff0033] bg-[#ff0033]/10">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="h-6 w-6 text-[#ff0033]" />
            <div>
              <h3 className="text-lg text-[#ff0033]">CRITICAL SECURITY ALERT</h3>
              <p className="text-sm">
                {compromisedDevices} device{compromisedDevices !== 1 ? 's' : ''} detected with security breaches. 
                Immediate action required.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;