import React, { useEffect, useState, useRef } from 'react';
import { Network, MonitorDot, Shield, Terminal, AlertTriangle, Play, Square, X, Settings, Users, Server, Menu } from 'lucide-react';
import { NetworkMap } from './components/NetworkMap';
import { StatusPanel } from './components/StatusPanel';
import { ThreatPanel } from './components/ThreatPanel';
import { LogPanel } from './components/LogPanel';
import { CustomInsightsPanel } from './components/CustomInsightsPanel';
import { AgentManagementPanel } from './components/AgentManagementPanel';
import { AuthPage } from './components/auth/AuthPage';
import { UserMenu } from './components/UserMenu';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { z } from 'zod';

interface Port {
  port: number;
  state: string;
  service: string;
  version: string;
  product: string;
}

interface OS {
  name: string;
  accuracy: number;
  family: string;
}

interface Device {
  ip: string;
  hostname: string;
  mac_address: string;
  manufacturer: string;
  device_type: string;
  model: string;
  os: OS;
  ports: Port[];
  status: string;
  last_seen: number;
}

interface SystemMetrics {
  cpu_usage: number;
  memory_total: number;
  memory_used: number;
  memory_free: number;
  disk_total?: number;
  disk_used?: number;
  disk_free?: number;
}

interface AgentScanData {
  agent_id: string;
  agent_type: 'local' | 'remote';
  devices: Device[];
  metrics: SystemMetrics;
  timestamp: number;
  scanning?: boolean;
  network_range?: string;
  received_at?: number;
  agent_info?: {
    ip: string;
    hostname: string;
    platform: string;
    version: string;
  };
}

interface AggregatedNetworkData {
  agents: Record<string, AgentScanData>;
  agent_count: number;
  local_agent: string;
  timestamp: number;
}

interface AgentStatus {
  type: 'local' | 'remote';
  last_seen: number;
  status: 'active' | 'stale';
  device_count: number;
  network_range: string;
}

interface ErrorState {
  message: string;
  type: 'error' | 'warning';
  details?: string;
}

// Get backend API URL from environment variables
const BACKEND_API_URL = import.meta.env.VITE_BACKEND_API_URL || 'http://localhost:5000';

function SettingsModal({ isOpen, onClose, apiKey, onSave, backendUrl, onBackendUrlSave }: {
  isOpen: boolean;
  onClose: () => void;
  apiKey: string;
  onSave: (key: string) => void;
  backendUrl: string;
  onBackendUrlSave: (url: string) => void;
}) {
  const [key, setKey] = useState(apiKey);
  const [url, setUrl] = useState(backendUrl);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="cyber-panel p-6 w-[600px] max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl neon-text">Network Monitor Settings</h2>
          <button onClick={onClose} className="p-2 hover:bg-[#222222] rounded">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-sm mb-2">Backend Server URL</label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="http://localhost:5000"
              className="w-full bg-[#111111] border border-[#00ff00] p-2 rounded text-[#00ff00] placeholder-[#00ff00]/50"
            />
            <p className="text-xs mt-2 opacity-60">
              Enter the URL of your backend server. Use localhost for local development or a public IP/domain for remote servers.
            </p>
          </div>

          <div>
            <label className="block text-sm mb-2">API Key (Optional)</label>
            <input
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="Enter your API key"
              className="w-full bg-[#111111] border border-[#00ff00] p-2 rounded text-[#00ff00] placeholder-[#00ff00]/50"
            />
            <p className="text-xs mt-2 opacity-60">
              Enter your API key to authenticate with the security insights service.
            </p>
          </div>

          <div className="cyber-panel p-4">
            <h3 className="text-sm mb-3 neon-text">Remote Agent Setup Instructions</h3>
            <div className="space-y-3 text-xs">
              <div>
                <p className="mb-2">1. Copy <code className="bg-[#222222] px-1 rounded">remote_scanner_agent.py</code> to the remote machine</p>
                <p className="mb-2">2. Install dependencies:</p>
                <code className="block bg-[#222222] p-2 rounded">pip install python-nmap psutil requests</code>
              </div>
              <div>
                <p className="mb-2">3. Run the agent (requires admin/sudo privileges):</p>
                <code className="block bg-[#222222] p-2 rounded">
                  sudo python remote_scanner_agent.py --server {url}
                </code>
              </div>
              <div>
                <p className="mb-2">4. Optional parameters:</p>
                <code className="block bg-[#222222] p-2 rounded">
                  --interval 60    # Scan interval in seconds<br/>
                  --test          # Run single test scan
                </code>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-[#00ff00] rounded hover:bg-[#00ff00]/20"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onSave(key);
                onBackendUrlSave(url);
                onClose();
              }}
              className="px-4 py-2 bg-[#00ff00] text-black rounded hover:bg-[#00ff00]/80"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ErrorMessage({ error, onClose }: { error: ErrorState; onClose: () => void }) {
  return (
    <div className={`cyber-panel p-4 mb-4 ${
      error.type === 'error' ? 'text-[#ff0033]' : 'text-[#f59e0b]'
    } flex items-start justify-between`}>
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 mt-1">
          {error.type === 'error' ? (
            <Shield className="h-5 w-5" />
          ) : (
            <AlertTriangle className="h-5 w-5" />
          )}
        </div>
        <div>
          <p className="font-medium">{error.message}</p>
          {error.details && (
            <p className="mt-1 text-sm opacity-80">{error.details}</p>
          )}
        </div>
      </div>
      <button
        onClick={onClose}
        className="p-1 hover:bg-[#ff0033]/20 rounded"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

function StatusIndicator({ status }: { status: 'idle' | 'loading' | 'success' | 'error' }) {
  const getStatusColor = () => {
    switch (status) {
      case 'loading': return 'text-[#f59e0b]';
      case 'success': return 'text-[#00ff00]';
      case 'error': return 'text-[#ff0033]';
      default: return 'text-gray-400';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'loading': return 'Scanning network...';
      case 'success': return 'Network scan complete';
      case 'error': return 'Scan failed';
      default: return 'Scanner idle';
    }
  };

  return (
    <div className={`flex items-center space-x-2 ${getStatusColor()}`}>
      {status === 'loading' && (
        <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
      )}
      <span className="text-sm">{getStatusText()}</span>
    </div>
  );
}

function MainApp() {
  const { user, session } = useAuth();
  const [networkData, setNetworkData] = useState<AggregatedNetworkData | null>(null);
  const [agentStatus, setAgentStatus] = useState<Record<string, AgentStatus>>({});
  const [error, setError] = useState<ErrorState | null>(null);
  const [fetchStatus, setFetchStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [isScanning, setIsScanning] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [backendUrl, setBackendUrl] = useState(BACKEND_API_URL);
  const [insights, setInsights] = useState(null);
  const [insightsError, setInsightsError] = useState<string | null>(null);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'network' | 'agents' | 'settings'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout>();

  const fetchInsights = async (data: AggregatedNetworkData) => {
    if (!apiKey) return;

    setIsLoadingInsights(true);
    setInsightsError(null);

    try {
      const response = await fetch(`${backendUrl}/api/insights`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error(`API returned ${response.status}`);
      }

      const result = await response.json();
      const validatedData = z.object({
        insights: z.array(z.object({
          severity: z.enum(['low', 'medium', 'high', 'critical']),
          title: z.string(),
          description: z.string(),
          recommendation: z.string().optional(),
        })),
      }).parse(result);
      
      setInsights(validatedData.insights);
    } catch (err) {
      console.error('Error fetching insights:', err);
      setInsightsError(err instanceof Error ? err.message : 'Failed to fetch security insights');
    } finally {
      setIsLoadingInsights(false);
    }
  };

  const fetchData = async () => {
    try {
      setFetchStatus('loading');
      
      const response = await fetch(`${backendUrl}/api/network`, {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      setNetworkData(data);
      setError(null);
      setFetchStatus('success');
    } catch (err) {
      console.error('Error fetching network data:', err);
      
      if (err.message.includes('Failed to fetch')) {
        setError({
          type: 'error',
          message: 'Failed to connect to network scanner',
          details: `Cannot reach backend server at ${backendUrl}. Please check the server URL in settings and ensure the Python server is running.`
        });
      } else {
        setError({
          type: 'error',
          message: 'Network scanning error',
          details: err.message
        });
      }
      setFetchStatus('error');
    }
  };

  const fetchAgentStatus = async () => {
    try {
      const response = await fetch(`${backendUrl}/api/agents/status`, {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const data = await response.json();
        setAgentStatus(data);
      }
    } catch (err) {
      console.error('Error fetching agent status:', err);
    }
  };

  const startScanning = async () => {
    try {
      const response = await fetch(`${backendUrl}/api/network/start`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`Failed to start scanning: ${response.status}`);
      }
      
      setIsScanning(true);
      fetchData();
      intervalRef.current = setInterval(() => {
        fetchData();
        fetchAgentStatus();
      }, 30000);
    } catch (err) {
      console.error('Error starting scan:', err);
      setError({
        type: 'error',
        message: 'Failed to start network scan',
        details: `Cannot reach backend server at ${backendUrl}. Please check the server URL in settings.`
      });
    }
  };

  const stopScanning = async () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = undefined;
    }

    try {
      const response = await fetch(`${backendUrl}/api/network/stop`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`Failed to stop scanning: ${response.status}`);
      }
      
      setIsScanning(false);
      setFetchStatus('idle');
    } catch (err) {
      console.error('Error stopping scan:', err);
      setError({
        type: 'error',
        message: 'Failed to stop network scan',
        details: err.message
      });
    }
  };

  // Aggregate data for components that expect single data structure
  const getAggregatedDevices = (): Device[] => {
    if (!networkData) return [];
    
    const allDevices: Device[] = [];
    Object.values(networkData.agents).forEach(agent => {
      allDevices.push(...agent.devices);
    });
    return allDevices;
  };

  const getAggregatedMetrics = (): SystemMetrics | undefined => {
    if (!networkData) return undefined;
    
    const agents = Object.values(networkData.agents);
    if (agents.length === 0) return undefined;
    
    // Return metrics from local agent if available, otherwise first agent
    const localAgent = agents.find(agent => agent.agent_type === 'local');
    return localAgent?.metrics || agents[0]?.metrics;
  };

  useEffect(() => {
    if (networkData && apiKey) {
      fetchInsights(networkData);
    }
  }, [networkData, apiKey]);

  useEffect(() => {
    // Initial fetch of agent status
    fetchAgentStatus();
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const renderMainContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <Dashboard
            networkData={networkData}
            agentStatus={agentStatus}
            metrics={getAggregatedMetrics()}
            devices={getAggregatedDevices()}
            insights={insights}
            isLoadingInsights={isLoadingInsights}
            insightsError={insightsError}
          />
        );
      case 'network':
        return <NetworkMap networkData={networkData} />;
      case 'agents':
        return (
          <div className="p-6">
            <AgentManagementPanel
              networkData={networkData}
              agentStatus={agentStatus}
              backendUrl={backendUrl}
            />
          </div>
        );
      case 'settings':
        return (
          <div className="p-6">
            <div className="max-w-2xl">
              <h1 className="text-2xl neon-text mb-6">Settings</h1>
              <div className="cyber-panel p-6">
                <h2 className="text-lg mb-4">Configuration</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm mb-2">Backend Server URL</label>
                    <input
                      type="text"
                      value={backendUrl}
                      onChange={(e) => setBackendUrl(e.target.value)}
                      className="w-full bg-[#111111] border border-[#00ff00] p-2 rounded text-[#00ff00]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2">API Key</label>
                    <input
                      type="password"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="w-full bg-[#111111] border border-[#00ff00] p-2 rounded text-[#00ff00]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex">
      {/* Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        activeView={activeView}
        onViewChange={setActiveView}
        networkData={networkData}
        agentStatus={agentStatus}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <Header
          onMenuClick={() => setSidebarOpen(true)}
          fetchStatus={fetchStatus}
          backendUrl={backendUrl}
          agentCount={networkData?.agent_count || 0}
          isScanning={isScanning}
          onStartScanning={startScanning}
          onStopScanning={stopScanning}
          onSettingsClick={() => setIsSettingsOpen(true)}
        />

        {/* Error Message */}
        {error && (
          <div className="p-4">
            <ErrorMessage error={error} onClose={() => setError(null)} />
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-auto">
          {renderMainContent()}
        </main>
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        apiKey={apiKey}
        onSave={setApiKey}
        backendUrl={backendUrl}
        onBackendUrlSave={setBackendUrl}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AuthenticatedApp />
    </AuthProvider>
  );
}

function AuthenticatedApp() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#00ff00] text-center">
          <div className="animate-spin h-8 w-8 border-2 border-[#00ff00] border-t-transparent rounded-full mx-auto mb-4" />
          <p>Initializing system...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return <MainApp />;
}

export default App;