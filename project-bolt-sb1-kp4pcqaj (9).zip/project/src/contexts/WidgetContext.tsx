import React, { createContext, useContext, useState } from 'react';

type WidgetPosition = {
  x: number;
  y: number;
  width: number;
  height: number;
};

type WidgetSettings = {
  id: string;
  title: string;
  visible: boolean;
  position: WidgetPosition;
};

type WidgetContextType = {
  widgets: WidgetSettings[];
  updateWidget: (id: string, settings: Partial<WidgetSettings>) => void;
  toggleWidget: (id: string) => void;
};

const defaultWidgets: WidgetSettings[] = [
  {
    id: 'status',
    title: 'SYSTEM STATUS',
    visible: false,
    position: { x: 20, y: 20, width: 300, height: 200 },
  },
  {
    id: 'threat',
    title: 'THREAT LEVEL',
    visible: false,
    position: { x: 340, y: 20, width: 300, height: 200 },
  },
  {
    id: 'logs',
    title: 'SYSTEM LOGS',
    visible: false,
    position: { x: 660, y: 20, width: 500, height: 400 },
  },
  {
    id: 'insights',
    title: 'SECURITY INSIGHTS',
    visible: false,
    position: { x: 20, y: 240, width: 400, height: 400 },
  },
];

const WidgetContext = createContext<WidgetContextType | null>(null);

export function WidgetProvider({ children }: { children: React.ReactNode }) {
  const [widgets, setWidgets] = useState<WidgetSettings[]>(defaultWidgets);

  const updateWidget = (id: string, settings: Partial<WidgetSettings>) => {
    setWidgets(prev => prev.map(widget => 
      widget.id === id ? { ...widget, ...settings } : widget
    ));
  };

  const toggleWidget = (id: string) => {
    setWidgets(prev => prev.map(widget =>
      widget.id === id ? { ...widget, visible: !widget.visible } : widget
    ));
  };

  return (
    <WidgetContext.Provider value={{ widgets, updateWidget, toggleWidget }}>
      {children}
    </WidgetContext.Provider>
  );
}

export const useWidgets = () => {
  const context = useContext(WidgetContext);
  if (!context) throw new Error('useWidgets must be used within a WidgetProvider');
  return context;
};